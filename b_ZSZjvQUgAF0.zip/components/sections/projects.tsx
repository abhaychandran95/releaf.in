"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, MapPin, Calendar, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const projectCategories = ["All", "Events", "Construction", "Government", "Religious"];

const projects = [
  {
    id: 1,
    title: "Kumbh Mela 2024",
    category: "Religious",
    location: "Prayagraj, UP",
    year: "2024",
    units: "500+",
    description:
      "Largest sanitation deployment for the world&apos;s biggest religious gathering.",
    image:
      "https://images.unsplash.com/photo-1609619385002-f40f1df9b7eb?q=80&w=2070&auto=format&fit=crop",
    featured: true,
  },
  {
    id: 2,
    title: "Mumbai Metro Line 3",
    category: "Construction",
    location: "Mumbai, MH",
    year: "2023-24",
    units: "200+",
    description:
      "Long-term sanitation partnership for India&apos;s largest metro project.",
    image:
      "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=2070&auto=format&fit=crop",
    featured: true,
  },
  {
    id: 3,
    title: "IPL 2024 Venues",
    category: "Events",
    location: "Multiple Cities",
    year: "2024",
    units: "150+",
    description:
      "Premium portable restrooms across IPL stadium venues nationwide.",
    image:
      "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=2005&auto=format&fit=crop",
    featured: false,
  },
  {
    id: 4,
    title: "Smart City Indore",
    category: "Government",
    location: "Indore, MP",
    year: "2023",
    units: "100+",
    description: "Public sanitation infrastructure for India&apos;s cleanest city initiative.",
    image:
      "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?q=80&w=2070&auto=format&fit=crop",
    featured: false,
  },
  {
    id: 5,
    title: "Sunburn Festival",
    category: "Events",
    location: "Goa",
    year: "2023",
    units: "80+",
    description:
      "VIP and standard units for Asia&apos;s biggest electronic music festival.",
    image:
      "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?q=80&w=2070&auto=format&fit=crop",
    featured: false,
  },
  {
    id: 6,
    title: "Delhi-Mumbai Expressway",
    category: "Construction",
    location: "Multi-State",
    year: "2022-24",
    units: "300+",
    description:
      "Sanitation support for India&apos;s longest expressway construction project.",
    image:
      "https://images.unsplash.com/photo-1545558014-8692077e9b5c?q=80&w=2070&auto=format&fit=crop",
    featured: true,
  },
];

export function ProjectsSection() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects =
    activeCategory === "All"
      ? projects
      : projects.filter((p) => p.category === activeCategory);

  return (
    <section className="bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 flex flex-col items-center justify-between gap-6 md:flex-row"
        >
          <div>
            <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              Our Projects
            </span>
            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
              Featured Installations
            </h2>
          </div>
          <Button asChild variant="outline">
            <Link href="/projects" className="flex items-center gap-2">
              View All Projects
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </motion.div>

        {/* Category Filter */}
        <div className="mb-10 flex flex-wrap justify-center gap-3">
          {projectCategories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={cn(
                "rounded-full px-5 py-2 text-sm font-medium transition-all",
                activeCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              )}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <motion.div layout className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project) => (
              <motion.article
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className={cn(
                  "group relative overflow-hidden rounded-2xl bg-card shadow-sm",
                  project.featured && "md:col-span-2 lg:col-span-1"
                )}
              >
                {/* Image */}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-forest/80 via-transparent to-transparent" />

                  {/* Category Badge */}
                  <div className="absolute left-4 top-4">
                    <span className="rounded-full bg-gold px-3 py-1 text-xs font-medium text-dark-forest">
                      {project.category}
                    </span>
                  </div>

                  {/* Featured Badge */}
                  {project.featured && (
                    <div className="absolute right-4 top-4">
                      <span className="rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                        Featured
                      </span>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="mb-2 font-serif text-xl font-bold text-card-foreground">
                    {project.title}
                  </h3>
                  <p className="mb-4 text-sm text-muted-foreground">
                    {project.description}
                  </p>

                  {/* Meta Info */}
                  <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{project.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>{project.year}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      <span>{project.units} units</span>
                    </div>
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
