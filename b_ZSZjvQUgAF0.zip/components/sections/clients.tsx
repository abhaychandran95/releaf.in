"use client";

import { motion } from "framer-motion";
import { Building2, Landmark, Factory, Tent, Users } from "lucide-react";

const clientCategories = [
  {
    icon: Landmark,
    title: "Government Bodies",
    examples: ["Municipal Corporations", "PWD Departments", "Smart City Projects"],
  },
  {
    icon: Building2,
    title: "Construction Companies",
    examples: ["L&T", "Godrej Properties", "Shapoorji Pallonji"],
  },
  {
    icon: Factory,
    title: "Industrial Clients",
    examples: ["Manufacturing Plants", "Refineries", "Power Plants"],
  },
  {
    icon: Tent,
    title: "Event Organizers",
    examples: ["Wedding Planners", "Corporate Events", "Music Festivals"],
  },
  {
    icon: Users,
    title: "Religious Institutions",
    examples: ["Temple Trusts", "Pilgrimage Sites", "Religious Gatherings"],
  },
];

const testimonials = [
  {
    quote:
      "Releaf has been our trusted partner for all construction site sanitation needs. Their prompt service and quality units have made site management significantly easier.",
    author: "Rajesh Kumar",
    role: "Project Manager",
    company: "Leading Construction Co.",
  },
  {
    quote:
      "The VIP portable restrooms for our corporate event were exceptional. Clean, well-maintained, and the staff was very professional. Highly recommended!",
    author: "Priya Sharma",
    role: "Event Director",
    company: "Premium Events Pvt. Ltd.",
  },
  {
    quote:
      "For our temple&apos;s annual festival, Releaf provided 100+ units with excellent maintenance throughout the 10-day event. Outstanding service!",
    author: "Swami Anandananda",
    role: "Trust Administrator",
    company: "Sri Vishnu Temple Trust",
  },
];

export function ClientsSection() {
  return (
    <section className="bg-secondary py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            Our Clients
          </span>
          <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
            Trusted by Industry Leaders
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            From government bodies to private corporations, we serve diverse
            sectors with unwavering commitment to quality.
          </p>
        </motion.div>

        {/* Client Categories */}
        <div className="mb-20 grid gap-6 sm:grid-cols-2 lg:grid-cols-5">
          {clientCategories.map((category, index) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="rounded-2xl bg-card p-6 text-center shadow-sm"
            >
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                <category.icon className="h-7 w-7" />
              </div>
              <h3 className="mb-3 font-serif font-semibold text-card-foreground">
                {category.title}
              </h3>
              <ul className="space-y-1 text-sm text-muted-foreground">
                {category.examples.map((example) => (
                  <li key={example}>{example}</li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.author}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative rounded-2xl bg-card p-8 shadow-sm"
            >
              {/* Quote Mark */}
              <div className="absolute -top-4 left-6 flex h-8 w-8 items-center justify-center rounded-full bg-gold text-dark-forest">
                <span className="font-serif text-xl font-bold">&quot;</span>
              </div>

              <p className="mb-6 italic leading-relaxed text-muted-foreground">
                &quot;{testimonial.quote}&quot;
              </p>

              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 font-serif text-lg font-bold text-primary">
                  {testimonial.author.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-card-foreground">
                    {testimonial.author}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {testimonial.role}, {testimonial.company}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
