"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Building2,
  Tent,
  Factory,
  Users,
  ArrowRight,
  CheckCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const solutions = [
  {
    id: "construction",
    icon: Building2,
    title: "Construction Sites",
    shortDesc: "Durable sanitation for project sites",
    description:
      "Heavy-duty portable toilets designed for the demanding conditions of construction environments. Built to withstand harsh weather and high-traffic usage.",
    features: [
      "Weather-resistant FRP construction",
      "Daily servicing available",
      "Bulk rental discounts",
      "Quick deployment within 24 hours",
    ],
    image:
      "https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/construction",
  },
  {
    id: "events",
    icon: Tent,
    title: "Events & Gatherings",
    shortDesc: "Premium restrooms for special occasions",
    description:
      "Elegant and hygienic portable restroom solutions for weddings, corporate events, festivals, and large gatherings. VIP units available for premium experiences.",
    features: [
      "VIP & premium units available",
      "Climate-controlled options",
      "Attendant services",
      "Flexible rental periods",
    ],
    image:
      "https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/events",
  },
  {
    id: "religious",
    icon: Users,
    title: "Religious Sites",
    shortDesc: "Solutions for temples & pilgrimages",
    description:
      "Respectful and accessible sanitation infrastructure for temples, religious gatherings, and pilgrimage sites. Designed with cultural sensitivity in mind.",
    features: [
      "High-capacity solutions",
      "Accessible units included",
      "24/7 maintenance support",
      "Eco-friendly waste management",
    ],
    image:
      "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?q=80&w=2076&auto=format&fit=crop",
    href: "/solutions/religious",
  },
  {
    id: "infrastructure",
    icon: Factory,
    title: "STP & Infrastructure",
    shortDesc: "Permanent wastewater solutions",
    description:
      "Complete sewage treatment plant design, installation, and maintenance. From small-scale residential to large municipal projects.",
    features: [
      "Custom capacity design",
      "Turnkey project delivery",
      "Annual maintenance contracts",
      "Compliance with standards",
    ],
    image:
      "https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/stp",
  },
];

export function SolutionsSection() {
  const [activeSolution, setActiveSolution] = useState(solutions[0]);

  return (
    <section className="bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            Our Solutions
          </span>
          <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
            Tailored Solutions for Every Need
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            From temporary event setups to permanent infrastructure, we provide
            comprehensive sanitation solutions across industries.
          </p>
        </motion.div>

        {/* Solutions Tabs */}
        <div className="mb-12 flex flex-wrap justify-center gap-3">
          {solutions.map((solution) => (
            <button
              key={solution.id}
              onClick={() => setActiveSolution(solution)}
              className={cn(
                "flex items-center gap-2 rounded-full px-6 py-3 font-medium transition-all",
                activeSolution.id === solution.id
                  ? "bg-primary text-primary-foreground shadow-lg"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              )}
            >
              <solution.icon className="h-5 w-5" />
              <span className="hidden sm:inline">{solution.title}</span>
            </button>
          ))}
        </div>

        {/* Active Solution Content */}
        <motion.div
          key={activeSolution.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="grid items-center gap-12 lg:grid-cols-2"
        >
          {/* Image */}
          <div className="relative overflow-hidden rounded-2xl">
            <div className="aspect-[4/3]">
              <img
                src={activeSolution.image}
                alt={activeSolution.title}
                className="h-full w-full object-cover"
              />
            </div>
            {/* Overlay with icon */}
            <div className="absolute bottom-6 left-6 flex items-center gap-3 rounded-xl bg-card/95 px-6 py-4 shadow-lg backdrop-blur-sm">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                <activeSolution.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="font-serif font-semibold text-card-foreground">
                  {activeSolution.title}
                </p>
                <p className="text-sm text-muted-foreground">
                  {activeSolution.shortDesc}
                </p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div>
            <h3 className="font-serif text-2xl font-bold text-foreground md:text-3xl">
              {activeSolution.title}
            </h3>
            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              {activeSolution.description}
            </p>

            {/* Features List */}
            <ul className="mt-8 space-y-4">
              {activeSolution.features.map((feature, index) => (
                <motion.li
                  key={feature}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <CheckCircle className="h-5 w-5 shrink-0 text-primary" />
                  <span className="text-foreground">{feature}</span>
                </motion.li>
              ))}
            </ul>

            {/* CTA */}
            <div className="mt-10 flex flex-wrap gap-4">
              <Button asChild size="lg">
                <Link
                  href={activeSolution.href}
                  className="flex items-center gap-2"
                >
                  Learn More
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/quote">Get a Quote</Link>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
