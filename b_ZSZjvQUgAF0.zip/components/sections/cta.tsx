"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Phone, MessageSquare, ArrowRight, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CTASection() {
  return (
    <section className="relative overflow-hidden bg-dark-forest py-20 lg:py-28">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute left-0 top-0 h-96 w-96 rounded-full bg-leaf/10 blur-3xl" />
        <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-gold/10 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          {/* Badge */}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-gold/30 bg-gold/10 px-4 py-2">
            <Clock className="h-4 w-4 text-gold" />
            <span className="text-sm font-medium text-gold">
              Get Response Within 24 Hours
            </span>
          </div>

          <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl lg:text-5xl">
            Ready to Discuss Your{" "}
            <span className="text-gold">Sanitation Needs?</span>
          </h2>

          <p className="mx-auto mt-6 max-w-2xl text-lg text-cream/80">
            Whether you need a single unit or hundreds, our team is ready to help
            you find the perfect solution. Get a customized quote tailored to your
            specific requirements.
          </p>

          {/* CTA Buttons */}
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button
              size="lg"
              asChild
              className="bg-gold text-dark-forest hover:bg-gold/90"
            >
              <Link href="/quote" className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Request a Quote
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="border-cream/30 text-cream hover:bg-cream/10"
            >
              <a href="tel:+919876543210" className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                Call +91 98765 43210
              </a>
            </Button>
          </div>

          {/* Quick Info */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-8 text-cream/70">
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-leaf" />
              <span>No commitment required</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-leaf" />
              <span>Free site assessment</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-leaf" />
              <span>Transparent pricing</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
