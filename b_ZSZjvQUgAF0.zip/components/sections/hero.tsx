"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight, Play, Award, Users, MapPin, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const stats = [
  { value: "33+", label: "Years of Excellence", icon: Award },
  { value: "1M+", label: "Lives Impacted", icon: Users },
  { value: "28", label: "States Covered", icon: MapPin },
];

export function HeroSection() {
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);

  return (
    <section className="relative min-h-[90vh] overflow-hidden bg-gradient-to-br from-dark-forest via-dark-forest to-forest">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(92,184,92,0.15),transparent_40%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_70%,rgba(184,134,11,0.1),transparent_40%)]" />
        <div className="absolute inset-0 bg-[url('/images/hero-portable-toilet.jpg')] bg-cover bg-center bg-no-repeat opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-r from-dark-forest via-dark-forest/95 to-dark-forest/80" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6 py-20 lg:py-28">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          {/* Content */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center lg:text-left"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="mb-8 inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/15 px-5 py-2.5 shadow-lg shadow-gold/10"
            >
              <Award className="h-5 w-5 text-gold" />
              <span className="text-sm font-semibold text-gold">
                India&apos;s Pioneer Since 1991
              </span>
            </motion.div>

            <h1 className="font-serif text-4xl font-bold leading-[1.1] text-cream md:text-5xl lg:text-6xl xl:text-7xl">
              Sustainable{" "}
              <span className="relative">
                <span className="text-leaf">Sanitation</span>
                <svg className="absolute -bottom-2 left-0 h-3 w-full" viewBox="0 0 200 12" fill="none">
                  <path d="M2 10C50 2 150 2 198 10" stroke="rgb(92 184 92)" strokeWidth="3" strokeLinecap="round" />
                </svg>
              </span>{" "}
              Solutions for a{" "}
              <span className="text-gold">Cleaner India</span>
            </h1>

            <p className="mt-8 text-lg leading-relaxed text-cream/80 md:text-xl">
              Premium portable toilets and wastewater management infrastructure.
              Trusted by governments, corporations, and event organizers across
              28 states.
            </p>

            {/* CTA Buttons */}
            <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row lg:justify-start">
              <Button
                size="lg"
                asChild
                className="rounded-full bg-gradient-to-r from-gold to-yellow-600 px-8 py-6 text-base font-semibold text-dark-forest shadow-xl shadow-gold/25 transition-all hover:shadow-2xl hover:shadow-gold/30"
              >
                <Link href="/solutions" className="flex items-center gap-2">
                  Explore Solutions
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setIsVideoPlaying(true)}
                className="group rounded-full border-2 border-cream/40 bg-cream/10 px-8 py-6 text-base font-semibold text-cream backdrop-blur-sm transition-all hover:border-cream hover:bg-transparent hover:text-white"
              >
                <Play className="mr-2 h-5 w-5 transition-transform group-hover:scale-110" />
                Watch Our Story
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="mt-14 flex flex-wrap items-center justify-center gap-8 lg:justify-start">
              <div className="text-center lg:text-left">
                <p className="text-sm font-medium text-cream/50">Trusted by</p>
                <p className="font-serif text-xl font-bold text-cream">
                  500+ Organizations
                </p>
              </div>
              <div className="hidden h-14 w-px bg-gradient-to-b from-transparent via-cream/30 to-transparent sm:block" />
              <div className="text-center lg:text-left">
                <p className="text-sm font-medium text-cream/50">Certified by</p>
                <p className="font-serif text-xl font-bold text-cream">
                  ISO 9001:2015
                </p>
              </div>
            </div>
          </motion.div>

          {/* Hero Image & Stats */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative hidden lg:block"
          >
            {/* Main Image Container */}
            <div className="relative">
              {/* Decorative elements */}
              <div className="absolute -right-10 -top-10 h-72 w-72 rounded-full bg-leaf/20 blur-3xl" />
              <div className="absolute -bottom-10 -left-10 h-56 w-56 rounded-full bg-gold/15 blur-3xl" />

              {/* Image */}
              <div className="relative overflow-hidden rounded-3xl border border-cream/10 shadow-2xl">
                <Image
                  src="/images/hero-portable-toilet.jpg"
                  alt="Premium Portable Sanitation Solutions"
                  width={600}
                  height={500}
                  className="h-[450px] w-full object-cover"
                  priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-forest/60 via-transparent to-transparent" />
              </div>

              {/* Stats Cards Overlay */}
              <div className="absolute -bottom-8 -left-8 right-8 grid grid-cols-3 gap-4">
                {stats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="rounded-2xl border border-cream/10 bg-dark-forest/90 p-4 text-center backdrop-blur-md"
                  >
                    <stat.icon className="mx-auto mb-2 h-6 w-6 text-gold" />
                    <p className="font-serif text-2xl font-bold text-cream">
                      {stat.value}
                    </p>
                    <p className="text-xs text-cream/70">{stat.label}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Mobile Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-16 grid grid-cols-3 gap-4 lg:hidden"
        >
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="rounded-2xl border border-cream/10 bg-cream/5 p-4 text-center backdrop-blur-sm"
            >
              <stat.icon className="mx-auto mb-2 h-6 w-6 text-gold" />
              <p className="font-serif text-2xl font-bold text-cream">
                {stat.value}
              </p>
              <p className="text-xs text-cream/70">{stat.label}</p>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="flex flex-col items-center gap-2">
          <span className="text-xs font-medium text-cream/50">Scroll to explore</span>
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="h-10 w-6 rounded-full border-2 border-cream/30"
          >
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
              className="mx-auto mt-2 h-2 w-1 rounded-full bg-gold"
            />
          </motion.div>
        </div>
      </motion.div>

      {/* Video Modal */}
      {isVideoPlaying && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-dark-forest/95 backdrop-blur-md"
          onClick={() => setIsVideoPlaying(false)}
        >
          <div className="relative aspect-video w-full max-w-4xl rounded-2xl bg-dark-forest p-2">
            <button
              onClick={() => setIsVideoPlaying(false)}
              className="absolute -right-4 -top-4 flex h-12 w-12 items-center justify-center rounded-full bg-cream text-dark-forest shadow-xl transition-transform hover:scale-110"
            >
              <X className="h-6 w-6" />
            </button>
            <div className="flex h-full items-center justify-center rounded-xl bg-cream/10">
              <div className="text-center">
                <Play className="mx-auto mb-4 h-16 w-16 text-cream/40" />
                <p className="text-cream/60">Video coming soon</p>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </section>
  );
}
