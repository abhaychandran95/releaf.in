"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, Building2, CheckCircle, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";

const regions = [
  {
    name: "North India",
    states: ["Delhi NCR", "Punjab", "Haryana", "UP", "Uttarakhand", "HP", "J&K"],
    coverage: "100%",
    units: "1500+",
    image: "/images/region-north.jpg",
    description: "Complete coverage across the National Capital Region and surrounding states with rapid deployment capabilities.",
  },
  {
    name: "West India",
    states: ["Maharashtra", "Gujarat", "Rajasthan", "Goa", "MP"],
    coverage: "100%",
    units: "2000+",
    image: "/images/region-west.jpg",
    description: "Strong presence in Mumbai, Pune, Ahmedabad and across industrial corridors of Western India.",
  },
  {
    name: "South India",
    states: ["Karnataka", "Tamil Nadu", "Kerala", "Telangana", "AP"],
    coverage: "100%",
    units: "1800+",
    image: "/images/region-south.jpg",
    description: "Extensive network covering major IT hubs, temple towns, and industrial centers across South India.",
  },
  {
    name: "East India",
    states: ["West Bengal", "Odisha", "Bihar", "Jharkhand", "Assam"],
    coverage: "85%",
    units: "800+",
    image: "/images/region-east.jpg",
    description: "Growing presence with focus on religious festivals, industrial projects, and urban development.",
  },
];

const highlights = [
  "28 States Covered",
  "500+ Cities",
  "5000+ Active Installations",
  "24-Hour Deployment",
];

export function CoverageMapSection() {
  const [activeRegion, setActiveRegion] = useState(regions[0]);

  return (
    <section className="bg-gradient-to-b from-secondary to-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full bg-forest/10 px-5 py-2 text-sm font-semibold text-forest">
            Our Reach
          </span>
          <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl lg:text-5xl">
            Pan-India Coverage
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-dark-forest/70">
            From metros to remote locations, we deliver sanitation solutions
            wherever you need them.
          </p>
        </motion.div>

        {/* Highlights Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 flex flex-wrap justify-center gap-4"
        >
          {highlights.map((highlight) => (
            <div
              key={highlight}
              className="flex items-center gap-2 rounded-full bg-white px-6 py-3 shadow-md"
            >
              <CheckCircle className="h-5 w-5 text-forest" />
              <span className="font-medium text-dark-forest">{highlight}</span>
            </div>
          ))}
        </motion.div>

        <div className="grid items-start gap-8 lg:grid-cols-2 lg:gap-12">
          {/* Interactive Map Visual */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            {/* Region Image with Map Overlay */}
            <div className="relative overflow-hidden rounded-3xl bg-white p-4 shadow-xl">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeRegion.name}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  className="relative aspect-[4/3] overflow-hidden rounded-2xl"
                >
                  <Image
                    src={activeRegion.image}
                    alt={`Releaf installations in ${activeRegion.name}`}
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-forest/80 via-dark-forest/20 to-transparent" />
                  
                  {/* Region Label Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gold text-dark-forest shadow-lg">
                        <MapPin className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-serif text-2xl font-bold text-cream">
                          {activeRegion.name}
                        </h3>
                        <p className="text-cream/80">{activeRegion.units} Active Units</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Region Selector Pills */}
              <div className="mt-4 flex flex-wrap gap-2">
                {regions.map((region) => (
                  <button
                    key={region.name}
                    onClick={() => setActiveRegion(region)}
                    className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                      activeRegion.name === region.name
                        ? "bg-forest text-white shadow-lg"
                        : "bg-forest/10 text-forest hover:bg-forest/20"
                    }`}
                  >
                    {region.name}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Region Details */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <AnimatePresence mode="wait">
              <motion.div
                key={activeRegion.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="rounded-3xl bg-white p-8 shadow-xl"
              >
                <div className="mb-6 flex items-center gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-forest to-dark-forest text-white shadow-lg">
                    <Building2 className="h-8 w-8" />
                  </div>
                  <div>
                    <h3 className="font-serif text-2xl font-bold text-dark-forest">
                      {activeRegion.name}
                    </h3>
                    <p className="text-forest">
                      {activeRegion.coverage} Regional Coverage
                    </p>
                  </div>
                </div>

                <p className="mb-6 text-dark-forest/70 leading-relaxed">
                  {activeRegion.description}
                </p>

                {/* Stats */}
                <div className="mb-6 grid grid-cols-2 gap-4">
                  <div className="rounded-2xl bg-forest/5 p-5 text-center">
                    <p className="font-serif text-3xl font-bold text-forest">
                      {activeRegion.units}
                    </p>
                    <p className="text-sm text-dark-forest/60">Active Units</p>
                  </div>
                  <div className="rounded-2xl bg-gold/10 p-5 text-center">
                    <p className="font-serif text-3xl font-bold text-gold">
                      {activeRegion.states.length}
                    </p>
                    <p className="text-sm text-dark-forest/60">States Covered</p>
                  </div>
                </div>

                {/* States List */}
                <div className="mb-6">
                  <p className="mb-3 text-sm font-semibold uppercase tracking-wider text-dark-forest/50">
                    States Covered:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {activeRegion.states.map((state) => (
                      <span
                        key={state}
                        className="rounded-full bg-forest/10 px-4 py-1.5 text-sm font-medium text-forest"
                      >
                        {state}
                      </span>
                    ))}
                  </div>
                </div>

                {/* CTA */}
                <Button asChild className="w-full rounded-full bg-gradient-to-r from-forest to-dark-forest py-6">
                  <Link href="/contact" className="flex items-center justify-center gap-2">
                    Request Service in {activeRegion.name}
                    <ChevronRight className="h-5 w-5" />
                  </Link>
                </Button>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
