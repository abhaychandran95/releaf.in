"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Award, Shield, Leaf, Clock, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const highlights = [
  {
    icon: Clock,
    title: "33+ Years",
    description: "Pioneering eco-sanitation since 1991",
  },
  {
    icon: Shield,
    title: "ISO Certified",
    description: "Quality management systems",
  },
  {
    icon: Award,
    title: "Industry Leader",
    description: "First portable toilet company in India",
  },
  {
    icon: Leaf,
    title: "Eco-Focused",
    description: "Sustainable practices at core",
  },
];

export function AboutSection() {
  return (
    <section className="bg-secondary py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          {/* Image Grid */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="overflow-hidden rounded-2xl">
                  <img
                    src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=1974&auto=format&fit=crop"
                    alt="Releaf team at work"
                    className="h-48 w-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <div className="overflow-hidden rounded-2xl">
                  <img
                    src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=2070&auto=format&fit=crop"
                    alt="Professional meeting"
                    className="h-64 w-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
              </div>
              <div className="mt-8 space-y-4">
                <div className="overflow-hidden rounded-2xl">
                  <img
                    src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop"
                    alt="Team collaboration"
                    className="h-64 w-full object-cover transition-transform duration-500 hover:scale-105"
                  />
                </div>
                <div className="overflow-hidden rounded-2xl bg-primary p-6 text-center text-primary-foreground">
                  <p className="font-serif text-4xl font-bold">1991</p>
                  <p className="mt-1 text-sm">Year Founded</p>
                </div>
              </div>
            </div>

            {/* Floating Badge */}
            <motion.div
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, type: "spring" }}
              className="absolute -bottom-6 -right-6 flex h-32 w-32 flex-col items-center justify-center rounded-full bg-gold text-dark-forest shadow-xl"
            >
              <span className="font-serif text-3xl font-bold">33+</span>
              <span className="text-sm font-medium">Years</span>
            </motion.div>
          </motion.div>

          {/* Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              About Releaf
            </span>

            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
              India&apos;s Pioneer in{" "}
              <span className="text-primary">Eco-Sanitation</span>
            </h2>

            <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
              Founded in 1991, Releaf has been at the forefront of India&apos;s
              sanitation revolution for over three decades. What started as a
              vision to provide dignified sanitation solutions has grown into the
              country&apos;s most trusted name in portable toilets and wastewater
              management.
            </p>

            <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
              Our commitment to quality, sustainability, and customer service has
              made us the preferred partner for governments, corporations, event
              organizers, and religious institutions across 28 states.
            </p>

            {/* Highlights Grid */}
            <div className="mt-10 grid grid-cols-2 gap-4">
              {highlights.map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-start gap-3 rounded-xl bg-card p-4"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-serif font-semibold text-card-foreground">
                      {item.title}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {item.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <div className="mt-10">
              <Button asChild size="lg">
                <Link href="/about" className="flex items-center gap-2">
                  Learn Our Story
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
