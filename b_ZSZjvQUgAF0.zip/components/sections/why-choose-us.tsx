"use client";

import { motion } from "framer-motion";
import {
  Clock,
  Shield,
  Headphones,
  Truck,
  Award,
  Wrench,
  Leaf,
  IndianRupee,
} from "lucide-react";

const features = [
  {
    icon: Clock,
    title: "24-Hour Deployment",
    description:
      "Quick turnaround time for urgent requirements. We deploy units within 24 hours across major cities.",
  },
  {
    icon: Shield,
    title: "Quality Assured",
    description:
      "ISO 9001:2015 certified operations ensuring consistent quality and compliance with all safety standards.",
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description:
      "Round-the-clock customer service and emergency support for all your sanitation needs.",
  },
  {
    icon: Truck,
    title: "Pan-India Reach",
    description:
      "Extensive network covering 28 states with dedicated logistics for timely delivery and servicing.",
  },
  {
    icon: Wrench,
    title: "Regular Maintenance",
    description:
      "Scheduled servicing and maintenance programs to keep all units in optimal working condition.",
  },
  {
    icon: Leaf,
    title: "Eco-Friendly",
    description:
      "Sustainable practices with water-saving technologies and responsible waste disposal methods.",
  },
  {
    icon: IndianRupee,
    title: "Competitive Pricing",
    description:
      "Transparent pricing with flexible rental plans designed to fit various budget requirements.",
  },
  {
    icon: Award,
    title: "Industry Experience",
    description:
      "33+ years of expertise handling projects of all sizes from small events to mega installations.",
  },
];

export function WhyChooseUsSection() {
  return (
    <section className="bg-background py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16 text-center"
        >
          <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            Why Releaf
          </span>
          <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl lg:text-5xl">
            Why Organizations Choose Us
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            Trusted by 500+ organizations for reliable, high-quality sanitation
            solutions backed by decades of experience.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className="group rounded-2xl border border-border bg-card p-6 transition-all hover:border-primary/30 hover:shadow-lg"
            >
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                <feature.icon className="h-7 w-7" />
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold text-card-foreground">
                {feature.title}
              </h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
