"use client";

import { useEffect, useState, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Droplets, Users, Building2, Recycle, TrendingUp } from "lucide-react";

const impactMetrics = [
  {
    icon: Droplets,
    value: 15000000,
    suffix: "+",
    label: "Liters Water Saved",
    description: "Through efficient recycling systems",
  },
  {
    icon: Users,
    value: 1000000,
    suffix: "+",
    label: "Users Served Daily",
    description: "Across all our installations",
  },
  {
    icon: Building2,
    value: 5000,
    suffix: "+",
    label: "Active Installations",
    description: "Pan-India coverage",
  },
  {
    icon: Recycle,
    value: 95,
    suffix: "%",
    label: "Waste Recycled",
    description: "Industry-leading efficiency",
  },
];

function AnimatedCounter({
  value,
  suffix,
  isInView,
}: {
  value: number;
  suffix: string;
  isInView: boolean;
}) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;

    const duration = 2000;
    const steps = 60;
    const stepValue = value / steps;
    let current = 0;

    const timer = setInterval(() => {
      current += stepValue;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [isInView, value]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + "M";
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(0) + "K";
    }
    return num.toString();
  };

  return (
    <span>
      {formatNumber(count)}
      {suffix}
    </span>
  );
}

export function ImpactCounterSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative overflow-hidden bg-primary py-20">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48Y2lyY2xlIGN4PSIzMCIgY3k9IjMwIiByPSIyIi8+PC9nPjwvZz48L3N2Zz4=')]" />
      </div>

      <div className="relative mx-auto max-w-7xl px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-cream/10 px-4 py-2">
            <TrendingUp className="h-4 w-4 text-cream" />
            <span className="text-sm font-medium text-cream">Our Impact</span>
          </div>
          <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl lg:text-5xl">
            Making a Measurable Difference
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-cream/80">
            Every installation contributes to a cleaner, more sustainable India.
            Here&apos;s the impact we&apos;ve made together.
          </p>
        </motion.div>

        {/* Metrics Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {impactMetrics.map((metric, index) => (
            <motion.div
              key={metric.label}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-2xl bg-cream/10 p-8 backdrop-blur-sm transition-all hover:bg-cream/15"
            >
              {/* Icon */}
              <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-xl bg-cream/10 text-cream transition-colors group-hover:bg-gold group-hover:text-dark-forest">
                <metric.icon className="h-8 w-8" />
              </div>

              {/* Value */}
              <div className="font-serif text-4xl font-bold text-cream md:text-5xl">
                <AnimatedCounter
                  value={metric.value}
                  suffix={metric.suffix}
                  isInView={isInView}
                />
              </div>

              {/* Label */}
              <p className="mt-2 font-serif text-lg font-semibold text-cream">
                {metric.label}
              </p>

              {/* Description */}
              <p className="mt-1 text-sm text-cream/70">{metric.description}</p>

              {/* Decorative Corner */}
              <div className="absolute -bottom-4 -right-4 h-24 w-24 rounded-full bg-cream/5 transition-transform group-hover:scale-150" />
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8 }}
          className="mt-12 text-center"
        >
          <p className="text-cream/80">
            Join 500+ organizations in building a cleaner future.{" "}
            <a
              href="/contact"
              className="font-semibold text-gold underline-offset-4 hover:underline"
            >
              Partner with us today
            </a>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
