"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  ChevronDown,
  Phone,
  Mail,
  MapPin,
  Droplets,
  Building2,
  Tent,
  Factory,
  Recycle,
  Users,
  Award,
  Target,
  FileText,
  Briefcase,
  MessageSquare,
  Home,
  BookOpen,
  Shield,
  Trophy,
  UsersRound,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navigationItems = [
  {
    label: "Home",
    href: "/",
  },
  {
    label: "About Us",
    href: "/about",
    megaMenu: {
      sections: [
        {
          title: "Company",
          items: [
            {
              label: "Our Story",
              href: "/about/story",
              icon: BookOpen,
              description: "33+ years of pioneering eco-sanitation",
            },
            {
              label: "Mission & Vision",
              href: "/about/mission",
              icon: Target,
              description: "Building a cleaner, healthier India",
            },
            {
              label: "Achievements",
              href: "/about/achievements",
              icon: Trophy,
              description: "Industry-leading milestones",
            },
          ],
        },
        {
          title: "Resources",
          items: [
            {
              label: "Certifications",
              href: "/about/certifications",
              icon: Shield,
              description: "Quality & compliance standards",
            },
            {
              label: "Our Team",
              href: "/about/team",
              icon: UsersRound,
              description: "Meet our leadership team",
            },
            {
              label: "Careers",
              href: "/careers",
              icon: Briefcase,
              description: "Join our growing team",
            },
          ],
        },
      ],
    },
  },
  {
    label: "Solutions",
    href: "/solutions",
    megaMenu: {
      sections: [
        {
          title: "Portable Sanitation",
          items: [
            {
              label: "Construction Sites",
              href: "/solutions/construction",
              icon: Building2,
              description: "Durable units for project sites",
            },
            {
              label: "Events & Gatherings",
              href: "/solutions/events",
              icon: Tent,
              description: "Premium event restrooms",
            },
            {
              label: "Religious Sites",
              href: "/solutions/religious",
              icon: Users,
              description: "Temple & pilgrimage solutions",
            },
          ],
        },
        {
          title: "Infrastructure",
          items: [
            {
              label: "STP Plants",
              href: "/solutions/stp",
              icon: Factory,
              description: "Sewage treatment solutions",
            },
            {
              label: "Wastewater Management",
              href: "/solutions/wastewater",
              icon: Droplets,
              description: "Complete water recycling",
            },
            {
              label: "Eco Solutions",
              href: "/solutions/eco",
              icon: Recycle,
              description: "Sustainable sanitation",
            },
          ],
        },
      ],
    },
  },
  {
    label: "Products",
    href: "/products",
    megaMenu: {
      sections: [
        {
          title: "Rental Units",
          items: [
            {
              label: "Standard Toilets",
              href: "/products/standard",
              icon: Building2,
              description: "Cost-effective solutions",
            },
            {
              label: "Premium Units",
              href: "/products/premium",
              icon: Award,
              description: "VIP & executive restrooms",
            },
            {
              label: "Accessible Units",
              href: "/products/accessible",
              icon: Users,
              description: "Wheelchair accessible",
            },
          ],
        },
        {
          title: "Purchase Options",
          items: [
            {
              label: "FRP Toilets",
              href: "/products/frp",
              icon: Factory,
              description: "Durable FRP units for sale",
            },
            {
              label: "Bio-Digester Units",
              href: "/products/bio-digester",
              icon: Recycle,
              description: "Eco-friendly waste processing",
            },
            {
              label: "Custom Solutions",
              href: "/products/custom",
              icon: Target,
              description: "Tailored to your needs",
            },
          ],
        },
      ],
    },
  },
  {
    label: "Projects",
    href: "/projects",
  },
  {
    label: "Contact",
    href: "/contact",
  },
];

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isMobileMenuOpen]);

  return (
    <>
      {/* Top Bar */}
      <div className="hidden bg-gradient-to-r from-dark-forest via-dark-forest to-forest text-cream lg:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-2.5 text-sm">
          <div className="flex items-center gap-8">
            <a
              href="tel:+919876543210"
              className="flex items-center gap-2 transition-colors hover:text-gold"
            >
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-gold/20">
                <Phone className="h-3 w-3" />
              </div>
              <span className="font-medium">+91 98765 43210</span>
            </a>
            <a
              href="mailto:info@releaf.co.in"
              className="flex items-center gap-2 transition-colors hover:text-gold"
            >
              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-gold/20">
                <Mail className="h-3 w-3" />
              </div>
              <span>info@releaf.co.in</span>
            </a>
          </div>
          <div className="flex items-center gap-2 rounded-full bg-gold/20 px-4 py-1">
            <MapPin className="h-4 w-4 text-gold" />
            <span className="font-medium">Serving Pan-India Since 1991</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header
        className={cn(
          "sticky top-0 z-50 w-full transition-all duration-500",
          isScrolled
            ? "bg-white/95 shadow-xl shadow-dark-forest/5 backdrop-blur-lg"
            : "bg-white"
        )}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3">
          {/* Logo */}
          <Link href="/" className="group flex items-center gap-3">
            <div className="relative flex h-14 w-14 items-center justify-center overflow-hidden rounded-2xl bg-gradient-to-br from-forest to-dark-forest shadow-lg transition-transform duration-300 group-hover:scale-105">
              <Droplets className="h-8 w-8 text-white" />
              <div className="absolute inset-0 bg-gradient-to-tr from-gold/20 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-2xl font-bold tracking-tight text-dark-forest">
                Releaf
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-forest/70">
                Eco-Sanitation
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden items-center gap-1 lg:flex">
            {navigationItems.map((item) => (
              <div
                key={item.label}
                className="relative"
                onMouseEnter={() =>
                  item.megaMenu && setActiveMenu(item.label)
                }
                onMouseLeave={() => setActiveMenu(null)}
              >
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-1 rounded-full px-5 py-2.5 text-sm font-medium transition-all duration-200",
                    "text-dark-forest/80 hover:bg-forest/10 hover:text-forest",
                    activeMenu === item.label && "bg-forest/10 text-forest"
                  )}
                >
                  {item.label === "Home" && <Home className="mr-1 h-4 w-4" />}
                  {item.label}
                  {item.megaMenu && (
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 transition-transform duration-200",
                        activeMenu === item.label && "rotate-180"
                      )}
                    />
                  )}
                </Link>

                {/* Mega Menu */}
                <AnimatePresence>
                  {item.megaMenu && activeMenu === item.label && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.98 }}
                      transition={{ duration: 0.2, ease: "easeOut" }}
                      className="absolute left-0 top-full pt-3"
                    >
                      <div className="w-[520px] overflow-hidden rounded-2xl border border-forest/10 bg-white p-6 shadow-2xl shadow-dark-forest/10">
                        <div className="grid grid-cols-2 gap-8">
                          {item.megaMenu.sections.map((section) => (
                            <div key={section.title}>
                              <h3 className="mb-4 text-xs font-bold uppercase tracking-wider text-forest/50">
                                {section.title}
                              </h3>
                              <ul className="space-y-1">
                                {section.items.map((subItem) => (
                                  <li key={subItem.label}>
                                    <Link
                                      href={subItem.href}
                                      className="group/item flex items-start gap-3 rounded-xl p-3 transition-all hover:bg-forest/5"
                                    >
                                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-forest/10 text-forest transition-all group-hover/item:bg-forest group-hover/item:text-white group-hover/item:shadow-lg">
                                        <subItem.icon className="h-5 w-5" />
                                      </div>
                                      <div>
                                        <span className="block text-sm font-semibold text-dark-forest">
                                          {subItem.label}
                                        </span>
                                        <span className="text-xs text-dark-forest/60">
                                          {subItem.description}
                                        </span>
                                      </div>
                                    </Link>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </nav>

          {/* CTA Buttons */}
          <div className="hidden items-center gap-3 lg:flex">
            <Button
              variant="outline"
              asChild
              className="rounded-full border-forest/20 px-5 text-forest hover:border-forest hover:bg-forest/5"
            >
              <Link href="/quote" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Get Quote
              </Link>
            </Button>
            <Button
              asChild
              className="rounded-full bg-gradient-to-r from-forest to-dark-forest px-6 shadow-lg shadow-forest/25 transition-all hover:shadow-xl hover:shadow-forest/30"
            >
              <Link href="/contact" className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                Call Now
              </Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="flex h-12 w-12 items-center justify-center rounded-xl text-dark-forest transition-colors hover:bg-forest/10 lg:hidden"
            aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="overflow-hidden border-t border-forest/10 bg-white lg:hidden"
            >
              <nav className="mx-auto max-w-7xl px-6 py-6">
                <ul className="space-y-1">
                  {navigationItems.map((item) => (
                    <li key={item.label}>
                      <Link
                        href={item.href}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="flex items-center justify-between rounded-xl px-4 py-3.5 font-medium text-dark-forest transition-colors hover:bg-forest/5 hover:text-forest"
                      >
                        <span className="flex items-center gap-2">
                          {item.label === "Home" && <Home className="h-4 w-4" />}
                          {item.label}
                        </span>
                        {item.megaMenu && (
                          <ChevronDown className="h-4 w-4 text-forest/50" />
                        )}
                      </Link>
                    </li>
                  ))}
                </ul>
                <div className="mt-6 flex flex-col gap-3 border-t border-forest/10 pt-6">
                  <Button
                    variant="outline"
                    asChild
                    className="w-full rounded-full border-forest/20"
                  >
                    <Link href="/quote">Get Quote</Link>
                  </Button>
                  <Button
                    asChild
                    className="w-full rounded-full bg-gradient-to-r from-forest to-dark-forest"
                  >
                    <Link href="/contact">Call Now</Link>
                  </Button>
                </div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}
