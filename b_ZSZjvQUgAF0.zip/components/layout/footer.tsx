"use client";

import Link from "next/link";
import {
  Droplets,
  Phone,
  Mail,
  MapPin,
  Facebook,
  Twitter,
  Linkedin,
  Instagram,
  ArrowRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const footerLinks = {
  company: [
    { label: "About Us", href: "/about" },
    { label: "Our Story", href: "/about/story" },
    { label: "Mission & Vision", href: "/about/mission" },
    { label: "Achievements", href: "/about/achievements" },
    { label: "Careers", href: "/careers" },
  ],
  solutions: [
    { label: "Construction Sites", href: "/solutions/construction" },
    { label: "Events & Gatherings", href: "/solutions/events" },
    { label: "Religious Sites", href: "/solutions/religious" },
    { label: "STP Plants", href: "/solutions/stp" },
    { label: "Wastewater Management", href: "/solutions/wastewater" },
  ],
  products: [
    { label: "Standard Toilets", href: "/products/standard" },
    { label: "Premium Units", href: "/products/premium" },
    { label: "Accessible Units", href: "/products/accessible" },
    { label: "FRP Toilets", href: "/products/frp" },
    { label: "Custom Solutions", href: "/products/custom" },
  ],
  support: [
    { label: "Contact Us", href: "/contact" },
    { label: "Get a Quote", href: "/quote" },
    { label: "FAQs", href: "/faqs" },
    { label: "Terms of Service", href: "/terms" },
    { label: "Privacy Policy", href: "/privacy" },
  ],
};

const socialLinks = [
  { icon: Facebook, href: "https://facebook.com/releaf", label: "Facebook" },
  { icon: Twitter, href: "https://twitter.com/releaf", label: "Twitter" },
  { icon: Linkedin, href: "https://linkedin.com/company/releaf", label: "LinkedIn" },
  { icon: Instagram, href: "https://instagram.com/releaf", label: "Instagram" },
];

export function Footer() {
  return (
    <footer className="bg-dark-forest text-cream">
      {/* CTA Section */}
      <div className="border-b border-cream/10">
        <div className="mx-auto max-w-7xl px-6 py-16">
          <div className="flex flex-col items-center justify-between gap-8 rounded-2xl bg-primary p-8 text-center md:flex-row md:p-12 md:text-left">
            <div>
              <h3 className="font-serif text-2xl font-bold text-primary-foreground md:text-3xl">
                Ready to transform your sanitation needs?
              </h3>
              <p className="mt-2 text-primary-foreground/80">
                Get a customized quote within 24 hours
              </p>
            </div>
            <Button
              size="lg"
              variant="secondary"
              asChild
              className="bg-cream text-dark-forest hover:bg-cream/90"
            >
              <Link href="/quote" className="flex items-center gap-2">
                Request Quote
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-6">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary">
                <Droplets className="h-7 w-7 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-2xl font-bold text-cream">
                  Releaf
                </span>
                <span className="text-xs tracking-wider text-cream/60">
                  ECO-SANITATION
                </span>
              </div>
            </Link>
            <p className="mt-6 leading-relaxed text-cream/70">
              India&apos;s pioneer in eco-sanitation since 1991. Providing premium
              portable sanitation and wastewater management solutions across the
              nation.
            </p>

            {/* Contact Info */}
            <div className="mt-8 space-y-4">
              <a
                href="tel:+919876543210"
                className="flex items-center gap-3 text-cream/70 transition-colors hover:text-gold"
              >
                <Phone className="h-5 w-5" />
                <span>+91 98765 43210</span>
              </a>
              <a
                href="mailto:info@releaf.co.in"
                className="flex items-center gap-3 text-cream/70 transition-colors hover:text-gold"
              >
                <Mail className="h-5 w-5" />
                <span>info@releaf.co.in</span>
              </a>
              <div className="flex items-start gap-3 text-cream/70">
                <MapPin className="h-5 w-5 shrink-0" />
                <span>
                  123 Green Avenue, Sector 15,
                  <br />
                  Mumbai, Maharashtra 400001
                </span>
              </div>
            </div>

            {/* Social Links */}
            <div className="mt-8 flex gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-cream/10 text-cream transition-colors hover:bg-gold hover:text-dark-forest"
                  aria-label={social.label}
                >
                  <social.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="font-serif text-lg font-semibold text-cream">
              Company
            </h4>
            <ul className="mt-6 space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-cream/70 transition-colors hover:text-gold"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold text-cream">
              Solutions
            </h4>
            <ul className="mt-6 space-y-3">
              {footerLinks.solutions.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-cream/70 transition-colors hover:text-gold"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold text-cream">
              Products
            </h4>
            <ul className="mt-6 space-y-3">
              {footerLinks.products.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-cream/70 transition-colors hover:text-gold"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg font-semibold text-cream">
              Support
            </h4>
            <ul className="mt-6 space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-cream/70 transition-colors hover:text-gold"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-cream/10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-6 text-sm text-cream/60 md:flex-row">
          <p>&copy; {new Date().getFullYear()} Releaf. All rights reserved.</p>
          <p className="flex items-center gap-2">
            <span>Made with</span>
            <span className="text-gold">commitment</span>
            <span>for a cleaner India</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
