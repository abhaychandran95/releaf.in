"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Building2,
  Tent,
  Users,
  Factory,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Calendar,
  MapPin,
  Phone,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const solutionTypes = [
  {
    id: "construction",
    icon: Building2,
    title: "Construction Sites",
    description: "Durable units for project sites",
  },
  {
    id: "events",
    icon: Tent,
    title: "Events & Gatherings",
    description: "Premium restrooms for occasions",
  },
  {
    id: "religious",
    icon: Users,
    title: "Religious Sites",
    description: "Temple & pilgrimage solutions",
  },
  {
    id: "infrastructure",
    icon: Factory,
    title: "STP & Infrastructure",
    description: "Permanent installations",
  },
];

const unitTypes = [
  { id: "standard", name: "Standard Units", priceRange: "Rs. 3,500-5,000/month" },
  { id: "premium", name: "Premium/VIP Units", priceRange: "Rs. 8,000-15,000/month" },
  { id: "accessible", name: "Accessible Units", priceRange: "Rs. 5,000-7,000/month" },
  { id: "trailer", name: "Trailer Restrooms", priceRange: "Rs. 25,000+/event" },
  { id: "purchase", name: "Purchase (FRP/Bio)", priceRange: "Rs. 45,000+ one-time" },
];

export default function QuotePage() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    solutionType: "",
    unitTypes: [] as string[],
    quantity: "",
    duration: "",
    startDate: "",
    location: "",
    name: "",
    email: "",
    phone: "",
    company: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSolutionSelect = (id: string) => {
    setFormData({ ...formData, solutionType: id });
  };

  const handleUnitTypeToggle = (id: string) => {
    const current = formData.unitTypes;
    if (current.includes(id)) {
      setFormData({ ...formData, unitTypes: current.filter((t) => t !== id) });
    } else {
      setFormData({ ...formData, unitTypes: [...current, id] });
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    setIsSubmitted(true);
  };

  const canProceedStep1 = formData.solutionType !== "";
  const canProceedStep2 = formData.unitTypes.length > 0 && formData.quantity !== "";
  const canProceedStep3 =
    formData.name !== "" && formData.email !== "" && formData.phone !== "";

  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-dark-forest py-16 lg:py-20">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-4 py-2 text-sm font-medium text-gold">
              Get a Quote
            </span>
            <h1 className="font-serif text-3xl font-bold text-cream md:text-4xl lg:text-5xl">
              Request Your <span className="text-leaf">Customized</span> Quote
            </h1>
            <p className="mt-4 text-lg text-cream/80">
              Tell us about your requirements and receive a tailored proposal
              within 24 hours.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Quote Form */}
      <section className="bg-background py-16">
        <div className="mx-auto max-w-4xl px-6">
          {/* Progress Steps */}
          <div className="mb-12">
            <div className="flex items-center justify-center">
              {[1, 2, 3].map((s) => (
                <div key={s} className="flex items-center">
                  <div
                    className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-full font-semibold transition-colors",
                      step >= s
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-muted-foreground"
                    )}
                  >
                    {step > s ? <CheckCircle className="h-5 w-5" /> : s}
                  </div>
                  {s < 3 && (
                    <div
                      className={cn(
                        "h-1 w-16 sm:w-24",
                        step > s ? "bg-primary" : "bg-secondary"
                      )}
                    />
                  )}
                </div>
              ))}
            </div>
            <div className="mt-4 flex justify-center gap-8 text-sm sm:gap-16">
              <span
                className={step >= 1 ? "text-primary" : "text-muted-foreground"}
              >
                Solution Type
              </span>
              <span
                className={step >= 2 ? "text-primary" : "text-muted-foreground"}
              >
                Requirements
              </span>
              <span
                className={step >= 3 ? "text-primary" : "text-muted-foreground"}
              >
                Contact Info
              </span>
            </div>
          </div>

          {isSubmitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="rounded-2xl bg-primary/10 p-12 text-center"
            >
              <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-primary text-primary-foreground">
                <CheckCircle className="h-10 w-10" />
              </div>
              <h2 className="font-serif text-3xl font-bold text-foreground">
                Quote Request Submitted!
              </h2>
              <p className="mx-auto mt-4 max-w-md text-muted-foreground">
                Thank you for your interest. Our team will review your
                requirements and send you a customized quote within 24 hours.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-4">
                <Button asChild>
                  <Link href="/">Return Home</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/projects">View Our Projects</Link>
                </Button>
              </div>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit}>
              {/* Step 1: Solution Type */}
              {step === 1 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h2 className="mb-6 text-center font-serif text-2xl font-bold text-foreground">
                    What type of solution do you need?
                  </h2>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {solutionTypes.map((solution) => (
                      <button
                        key={solution.id}
                        type="button"
                        onClick={() => handleSolutionSelect(solution.id)}
                        className={cn(
                          "flex items-start gap-4 rounded-xl border-2 p-6 text-left transition-all",
                          formData.solutionType === solution.id
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/50"
                        )}
                      >
                        <div
                          className={cn(
                            "flex h-12 w-12 shrink-0 items-center justify-center rounded-lg",
                            formData.solutionType === solution.id
                              ? "bg-primary text-primary-foreground"
                              : "bg-secondary text-secondary-foreground"
                          )}
                        >
                          <solution.icon className="h-6 w-6" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-foreground">
                            {solution.title}
                          </h3>
                          <p className="mt-1 text-sm text-muted-foreground">
                            {solution.description}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                  <div className="mt-8 flex justify-end">
                    <Button
                      type="button"
                      onClick={() => setStep(2)}
                      disabled={!canProceedStep1}
                    >
                      Continue
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Requirements */}
              {step === 2 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h2 className="mb-6 text-center font-serif text-2xl font-bold text-foreground">
                    Tell us about your requirements
                  </h2>

                  {/* Unit Types */}
                  <div className="mb-8">
                    <label className="mb-4 block font-medium text-foreground">
                      Select Unit Types (multiple allowed)
                    </label>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {unitTypes.map((unit) => (
                        <button
                          key={unit.id}
                          type="button"
                          onClick={() => handleUnitTypeToggle(unit.id)}
                          className={cn(
                            "flex items-center justify-between rounded-lg border-2 p-4 text-left transition-all",
                            formData.unitTypes.includes(unit.id)
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/50"
                          )}
                        >
                          <div>
                            <p className="font-medium text-foreground">
                              {unit.name}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {unit.priceRange}
                            </p>
                          </div>
                          <div
                            className={cn(
                              "flex h-6 w-6 items-center justify-center rounded-full border-2",
                              formData.unitTypes.includes(unit.id)
                                ? "border-primary bg-primary text-primary-foreground"
                                : "border-muted-foreground"
                            )}
                          >
                            {formData.unitTypes.includes(unit.id) && (
                              <CheckCircle className="h-4 w-4" />
                            )}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Other Fields */}
                  <div className="grid gap-6 sm:grid-cols-2">
                    <div>
                      <label className="mb-2 block text-sm font-medium text-foreground">
                        Approximate Quantity *
                      </label>
                      <select
                        name="quantity"
                        value={formData.quantity}
                        onChange={handleChange}
                        required
                        className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground focus:border-primary focus:outline-none"
                      >
                        <option value="">Select quantity</option>
                        <option value="1-10">1-10 units</option>
                        <option value="11-50">11-50 units</option>
                        <option value="51-100">51-100 units</option>
                        <option value="100+">100+ units</option>
                      </select>
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-foreground">
                        Duration
                      </label>
                      <select
                        name="duration"
                        value={formData.duration}
                        onChange={handleChange}
                        className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground focus:border-primary focus:outline-none"
                      >
                        <option value="">Select duration</option>
                        <option value="1-3 days">1-3 days</option>
                        <option value="1 week">1 week</option>
                        <option value="1 month">1 month</option>
                        <option value="3+ months">3+ months</option>
                        <option value="permanent">Permanent/Purchase</option>
                      </select>
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-foreground">
                        Start Date
                      </label>
                      <input
                        type="date"
                        name="startDate"
                        value={formData.startDate}
                        onChange={handleChange}
                        className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-foreground">
                        Location
                      </label>
                      <input
                        type="text"
                        name="location"
                        value={formData.location}
                        onChange={handleChange}
                        placeholder="City, State"
                        className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="mt-8 flex justify-between">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep(1)}
                    >
                      <ArrowLeft className="mr-2 h-5 w-5" />
                      Back
                    </Button>
                    <Button
                      type="button"
                      onClick={() => setStep(3)}
                      disabled={!canProceedStep2}
                    >
                      Continue
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Contact Info */}
              {step === 3 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <h2 className="mb-6 text-center font-serif text-2xl font-bold text-foreground">
                    Your Contact Information
                  </h2>

                  <div className="space-y-6">
                    <div className="grid gap-6 sm:grid-cols-2">
                      <div>
                        <label className="mb-2 block text-sm font-medium text-foreground">
                          Full Name *
                        </label>
                        <input
                          type="text"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          required
                          className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                          placeholder="John Doe"
                        />
                      </div>
                      <div>
                        <label className="mb-2 block text-sm font-medium text-foreground">
                          Company Name
                        </label>
                        <input
                          type="text"
                          name="company"
                          value={formData.company}
                          onChange={handleChange}
                          className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                          placeholder="ABC Ltd."
                        />
                      </div>
                    </div>
                    <div className="grid gap-6 sm:grid-cols-2">
                      <div>
                        <label className="mb-2 block text-sm font-medium text-foreground">
                          Email Address *
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          required
                          className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                          placeholder="john@company.com"
                        />
                      </div>
                      <div>
                        <label className="mb-2 block text-sm font-medium text-foreground">
                          Phone Number *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleChange}
                          required
                          className="w-full rounded-lg border border-input bg-card px-4 py-3 text-card-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                          placeholder="+91 98765 43210"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="mb-2 block text-sm font-medium text-foreground">
                        Additional Message
                      </label>
                      <textarea
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        rows={4}
                        className="w-full resize-none rounded-lg border border-input bg-card px-4 py-3 text-card-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
                        placeholder="Any specific requirements or questions..."
                      />
                    </div>
                  </div>

                  <div className="mt-8 flex justify-between">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setStep(2)}
                    >
                      <ArrowLeft className="mr-2 h-5 w-5" />
                      Back
                    </Button>
                    <Button type="submit" disabled={!canProceedStep3 || isSubmitting}>
                      {isSubmitting ? "Submitting..." : "Submit Quote Request"}
                    </Button>
                  </div>
                </motion.div>
              )}
            </form>
          )}
        </div>
      </section>

      {/* Quick Contact */}
      {!isSubmitted && (
        <section className="bg-secondary py-12">
          <div className="mx-auto max-w-4xl px-6 text-center">
            <p className="text-muted-foreground">
              Prefer to talk? Call us directly at{" "}
              <a
                href="tel:+919876543210"
                className="font-semibold text-primary hover:underline"
              >
                +91 98765 43210
              </a>
            </p>
          </div>
        </section>
      )}

      <Footer />
    </main>
  );
}
