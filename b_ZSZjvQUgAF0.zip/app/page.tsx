import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/sections/hero";
import { ImpactCounterSection } from "@/components/sections/impact-counter";
import { AboutSection } from "@/components/sections/about";
import { SolutionsSection } from "@/components/sections/solutions";
import { WhyChooseUsSection } from "@/components/sections/why-choose-us";
import { ProjectsSection } from "@/components/sections/projects";
import { CoverageMapSection } from "@/components/sections/coverage-map";
import { ClientsSection } from "@/components/sections/clients";
import { CTASection } from "@/components/sections/cta";

export default function HomePage() {
  return (
    <main>
      <Header />
      <HeroSection />
      <ImpactCounterSection />
      <AboutSection />
      <SolutionsSection />
      <WhyChooseUsSection />
      <ProjectsSection />
      <CoverageMapSection />
      <ClientsSection />
      <CTASection />
      <Footer />
    </main>
  );
}
