"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Briefcase,
  MapPin,
  Clock,
  ArrowRight,
  CheckCircle,
  Heart,
  TrendingUp,
  Users,
  Award,
  Building2,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const departments = ["All", "Operations", "Sales", "Engineering", "Corporate"];

const openings = [
  {
    title: "Regional Operations Manager",
    department: "Operations",
    location: "Mumbai, Maharashtra",
    type: "Full-time",
    experience: "8-12 years",
    description: "Lead regional operations, manage teams, and ensure service excellence across the Western region.",
  },
  {
    title: "Business Development Executive",
    department: "Sales",
    location: "Delhi NCR",
    type: "Full-time",
    experience: "3-5 years",
    description: "Drive B2B sales, build client relationships, and achieve revenue targets in the infrastructure sector.",
  },
  {
    title: "Project Engineer - STP",
    department: "Engineering",
    location: "Bangalore, Karnataka",
    type: "Full-time",
    experience: "5-8 years",
    description: "Design and oversee sewage treatment plant projects from conception to commissioning.",
  },
  {
    title: "Fleet Operations Supervisor",
    department: "Operations",
    location: "Chennai, Tamil Nadu",
    type: "Full-time",
    experience: "4-6 years",
    description: "Manage fleet logistics, coordinate deployments, and optimize service routes.",
  },
  {
    title: "HR Business Partner",
    department: "Corporate",
    location: "Mumbai, Maharashtra",
    type: "Full-time",
    experience: "6-8 years",
    description: "Partner with business leaders on talent strategy, employee engagement, and organizational development.",
  },
  {
    title: "Sales Executive - Events",
    department: "Sales",
    location: "Hyderabad, Telangana",
    type: "Full-time",
    experience: "2-4 years",
    description: "Focus on event and hospitality sector clients, manage key accounts and drive new business.",
  },
];

const benefits = [
  {
    icon: Heart,
    title: "Health & Wellness",
    description: "Comprehensive health insurance, annual health checkups, and wellness programs",
  },
  {
    icon: TrendingUp,
    title: "Growth Opportunities",
    description: "Clear career progression paths, learning budgets, and leadership development programs",
  },
  {
    icon: Users,
    title: "Great Culture",
    description: "Collaborative environment, team outings, and celebration of milestones",
  },
  {
    icon: Award,
    title: "Recognition",
    description: "Performance bonuses, spot awards, and annual recognition programs",
  },
];

const values = [
  "Making a real impact on public health and sanitation",
  "Working with cutting-edge environmental technology",
  "Being part of a legacy spanning 33+ years",
  "Opportunities to work on landmark projects",
  "Competitive compensation and growth",
];

export default function CareersPage() {
  const [activeDepartment, setActiveDepartment] = useState("All");

  const filteredOpenings = activeDepartment === "All"
    ? openings
    : openings.filter((job) => job.department === activeDepartment);

  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-dark-forest via-dark-forest to-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-5 py-2 text-sm font-semibold text-gold">
              Join Our Team
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Build Your Career at{" "}
              <span className="text-leaf">Releaf</span>
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              Join India&apos;s pioneer in eco-sanitation and make a meaningful
              impact on public health and environmental sustainability.
            </p>
            <div className="mt-10">
              <Button size="lg" asChild className="rounded-full bg-gold text-dark-forest hover:bg-gold/90">
                <a href="#openings" className="flex items-center gap-2">
                  View Open Positions
                  <ArrowRight className="h-5 w-5" />
                </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Why Join Us */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
                Why Releaf
              </span>
              <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
                More Than Just a Job
              </h2>
              <p className="mt-4 text-lg text-dark-forest/70">
                At Releaf, you&apos;ll be part of a mission that matters. Every day,
                our work impacts millions of lives by providing essential
                sanitation infrastructure across India.
              </p>
              <div className="mt-8 space-y-4">
                {values.map((value) => (
                  <div key={value} className="flex items-start gap-3">
                    <CheckCircle className="mt-0.5 h-5 w-5 shrink-0 text-forest" />
                    <span className="text-dark-forest/80">{value}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-4"
            >
              {benefits.map((benefit, index) => (
                <div
                  key={benefit.title}
                  className={cn(
                    "rounded-2xl p-6 shadow-lg",
                    index % 2 === 0 ? "bg-forest/5" : "bg-gold/5",
                    index === 0 && "mt-8",
                    index === 3 && "-mt-8"
                  )}
                >
                  <benefit.icon className={cn("mb-4 h-8 w-8", index % 2 === 0 ? "text-forest" : "text-gold")} />
                  <h3 className="font-serif text-lg font-semibold text-dark-forest">
                    {benefit.title}
                  </h3>
                  <p className="mt-2 text-sm text-dark-forest/70">{benefit.description}</p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section id="openings" className="bg-gradient-to-b from-secondary to-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
              Open Positions
            </span>
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Current Opportunities
            </h2>
          </motion.div>

          {/* Department Filter */}
          <div className="mb-10 flex flex-wrap justify-center gap-3">
            {departments.map((dept) => (
              <button
                key={dept}
                onClick={() => setActiveDepartment(dept)}
                className={cn(
                  "rounded-full px-6 py-2.5 text-sm font-medium transition-all",
                  activeDepartment === dept
                    ? "bg-forest text-white shadow-lg"
                    : "bg-white text-dark-forest hover:bg-forest/10"
                )}
              >
                {dept}
              </button>
            ))}
          </div>

          {/* Job Listings */}
          <div className="space-y-4">
            {filteredOpenings.map((job, index) => (
              <motion.div
                key={job.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group rounded-2xl bg-white p-6 shadow-lg transition-all hover:shadow-xl"
              >
                <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                  <div>
                    <div className="mb-2 flex flex-wrap items-center gap-2">
                      <span className="rounded-full bg-forest/10 px-3 py-1 text-xs font-medium text-forest">
                        {job.department}
                      </span>
                      <span className="rounded-full bg-gold/10 px-3 py-1 text-xs font-medium text-gold">
                        {job.type}
                      </span>
                    </div>
                    <h3 className="font-serif text-xl font-bold text-dark-forest">
                      {job.title}
                    </h3>
                    <p className="mt-2 text-dark-forest/70">{job.description}</p>
                    <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-dark-forest/60">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {job.location}
                      </span>
                      <span className="flex items-center gap-1">
                        <Briefcase className="h-4 w-4" />
                        {job.experience}
                      </span>
                    </div>
                  </div>
                  <Button asChild className="shrink-0 rounded-full">
                    <Link href={`/careers/${job.title.toLowerCase().replace(/\s+/g, "-")}`}>
                      Apply Now
                    </Link>
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Building2 className="mx-auto mb-6 h-16 w-16 text-forest" />
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Don&apos;t See a Fit?
            </h2>
            <p className="mt-4 text-lg text-dark-forest/70">
              We&apos;re always looking for talented individuals. Send us your resume
              and we&apos;ll reach out when a suitable opportunity arises.
            </p>
            <div className="mt-10">
              <Button size="lg" asChild className="rounded-full">
                <Link href="/contact" className="flex items-center gap-2">
                  Send Your Resume
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
