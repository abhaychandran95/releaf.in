"use client";

import { useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, Calendar, Users, ArrowRight, Building2 } from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const categories = ["All", "Events", "Construction", "Government", "Religious"];

const projects = [
  {
    id: 1,
    title: "Kumbh Mela 2024",
    category: "Religious",
    location: "Prayagraj, Uttar Pradesh",
    year: "2024",
    units: "500+",
    duration: "45 days",
    description:
      "Largest sanitation deployment for the world&apos;s biggest religious gathering, serving millions of devotees with round-the-clock maintenance.",
    challenge:
      "Managing sanitation for 10+ million daily visitors while maintaining hygiene standards.",
    solution:
      "Deployed 500+ units with 200+ maintenance staff, implementing 4-hour cleaning cycles.",
    image:
      "https://images.unsplash.com/photo-1609619385002-f40f1df9b7eb?q=80&w=2070&auto=format&fit=crop",
    featured: true,
  },
  {
    id: 2,
    title: "Mumbai Metro Line 3",
    category: "Construction",
    location: "Mumbai, Maharashtra",
    year: "2023-24",
    units: "200+",
    duration: "36 months",
    description:
      "Long-term sanitation partnership for India&apos;s largest metro construction project with units deployed across 26 underground stations.",
    challenge:
      "Providing sanitation in confined underground construction spaces with limited access.",
    solution:
      "Custom-designed compact units with specialized servicing vehicles for underground deployment.",
    image:
      "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=2070&auto=format&fit=crop",
    featured: true,
  },
  {
    id: 3,
    title: "IPL 2024 Venues",
    category: "Events",
    location: "Multiple Cities",
    year: "2024",
    units: "150+",
    duration: "2 months",
    description:
      "Premium portable restrooms across IPL stadium venues nationwide, including VIP units for player areas and hospitality zones.",
    challenge: "Simultaneous deployment across 10 cities with consistent quality standards.",
    solution: "Regional hub strategy with pre-positioned inventory and dedicated event teams.",
    image:
      "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?q=80&w=2005&auto=format&fit=crop",
    featured: false,
  },
  {
    id: 4,
    title: "Smart City Indore",
    category: "Government",
    location: "Indore, Madhya Pradesh",
    year: "2023",
    units: "100+",
    duration: "Ongoing",
    description:
      "Public sanitation infrastructure partnership for India&apos;s cleanest city initiative with permanent installations across the city.",
    challenge: "Meeting stringent cleanliness standards for India&apos;s cleanest city.",
    solution: "IoT-enabled monitoring system with real-time usage tracking and automatic alerts.",
    image:
      "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?q=80&w=2070&auto=format&fit=crop",
    featured: false,
  },
  {
    id: 5,
    title: "Sunburn Festival",
    category: "Events",
    location: "Goa",
    year: "2023",
    units: "80+",
    duration: "3 days",
    description:
      "VIP and standard units for Asia&apos;s biggest electronic music festival, handling peak crowds of 50,000+ attendees.",
    challenge: "Managing sudden peak loads during headline performances.",
    solution: "Strategic placement based on crowd flow analysis with rapid response cleaning teams.",
    image:
      "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?q=80&w=2070&auto=format&fit=crop",
    featured: false,
  },
  {
    id: 6,
    title: "Delhi-Mumbai Expressway",
    category: "Construction",
    location: "Multi-State",
    year: "2022-24",
    units: "300+",
    duration: "30 months",
    description:
      "Sanitation support for India&apos;s longest expressway construction project spanning 1,350 km across 6 states.",
    challenge: "Servicing units across remote locations with varying terrain and accessibility.",
    solution: "Mobile service fleet with satellite-based tracking and regional service hubs.",
    image:
      "https://images.unsplash.com/photo-1545558014-8692077e9b5c?q=80&w=2070&auto=format&fit=crop",
    featured: true,
  },
  {
    id: 7,
    title: "Tirumala Temple Complex",
    category: "Religious",
    location: "Tirupati, Andhra Pradesh",
    year: "2023",
    units: "150+",
    duration: "Ongoing",
    description:
      "Permanent sanitation infrastructure for one of the world&apos;s most visited religious sites with 100,000+ daily visitors.",
    challenge: "Maintaining hygiene for continuous high footfall with minimal service disruption.",
    solution: "Night-shift intensive maintenance with backup units to ensure zero downtime.",
    image:
      "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?q=80&w=2076&auto=format&fit=crop",
    featured: false,
  },
  {
    id: 8,
    title: "G20 Summit Venues",
    category: "Government",
    location: "New Delhi",
    year: "2023",
    units: "250+",
    duration: "2 weeks",
    description:
      "Premium sanitation facilities for the prestigious G20 Summit, meeting international standards for global dignitaries.",
    challenge: "Meeting security protocols while maintaining world-class facility standards.",
    solution: "Pre-screened staff with security clearance and premium units with enhanced features.",
    image:
      "https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?q=80&w=2070&auto=format&fit=crop",
    featured: true,
  },
];

export default function ProjectsPage() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [selectedProject, setSelectedProject] = useState<(typeof projects)[0] | null>(null);

  const filteredProjects =
    activeCategory === "All"
      ? projects
      : projects.filter((p) => p.category === activeCategory);

  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-dark-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-4 py-2 text-sm font-medium text-gold">
              Our Projects
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Landmark <span className="text-leaf">Installations</span> Across
              India
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              Explore our portfolio of successful sanitation deployments for
              governments, corporations, and major events.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          {/* Category Filter */}
          <div className="mb-12 flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={cn(
                  "rounded-full px-6 py-3 font-medium transition-all",
                  activeCategory === category
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                )}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Projects Grid */}
          <motion.div layout className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence mode="popLayout">
              {filteredProjects.map((project) => (
                <motion.article
                  key={project.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  className="group cursor-pointer overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all hover:shadow-lg"
                  onClick={() => setSelectedProject(project)}
                >
                  {/* Image */}
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-dark-forest/80 via-transparent to-transparent" />

                    {/* Badges */}
                    <div className="absolute left-4 top-4 flex gap-2">
                      <span className="rounded-full bg-gold px-3 py-1 text-xs font-medium text-dark-forest">
                        {project.category}
                      </span>
                      {project.featured && (
                        <span className="rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                          Featured
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="font-serif text-xl font-bold text-card-foreground">
                      {project.title}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                      {project.description}
                    </p>

                    {/* Meta */}
                    <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        <span>{project.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Building2 className="h-4 w-4" />
                        <span>{project.units} units</span>
                      </div>
                    </div>
                  </div>
                </motion.article>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-dark-forest/90 p-4 backdrop-blur-sm"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="relative max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl bg-card"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-dark-forest/80 text-cream transition-colors hover:bg-dark-forest"
              >
                &times;
              </button>

              {/* Image */}
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-dark-forest/60 via-transparent to-transparent" />
              </div>

              {/* Content */}
              <div className="p-8">
                <div className="mb-4 flex flex-wrap gap-2">
                  <span className="rounded-full bg-gold px-3 py-1 text-sm font-medium text-dark-forest">
                    {selectedProject.category}
                  </span>
                  <span className="rounded-full bg-secondary px-3 py-1 text-sm text-secondary-foreground">
                    {selectedProject.year}
                  </span>
                </div>

                <h2 className="font-serif text-3xl font-bold text-card-foreground">
                  {selectedProject.title}
                </h2>

                <p className="mt-4 text-lg text-muted-foreground">
                  {selectedProject.description}
                </p>

                {/* Stats */}
                <div className="mt-8 grid grid-cols-3 gap-4 rounded-xl bg-secondary p-6">
                  <div className="text-center">
                    <p className="font-serif text-2xl font-bold text-primary">
                      {selectedProject.units}
                    </p>
                    <p className="text-sm text-muted-foreground">Units Deployed</p>
                  </div>
                  <div className="text-center">
                    <p className="font-serif text-2xl font-bold text-primary">
                      {selectedProject.duration}
                    </p>
                    <p className="text-sm text-muted-foreground">Duration</p>
                  </div>
                  <div className="text-center">
                    <p className="font-serif text-2xl font-bold text-primary">24/7</p>
                    <p className="text-sm text-muted-foreground">Support</p>
                  </div>
                </div>

                {/* Challenge & Solution */}
                <div className="mt-8 grid gap-6 md:grid-cols-2">
                  <div className="rounded-xl border border-border p-6">
                    <h4 className="mb-3 font-serif font-semibold text-card-foreground">
                      The Challenge
                    </h4>
                    <p className="text-muted-foreground">{selectedProject.challenge}</p>
                  </div>
                  <div className="rounded-xl border border-primary/30 bg-primary/5 p-6">
                    <h4 className="mb-3 font-serif font-semibold text-primary">
                      Our Solution
                    </h4>
                    <p className="text-muted-foreground">{selectedProject.solution}</p>
                  </div>
                </div>

                {/* CTA */}
                <div className="mt-8 flex gap-4">
                  <Button asChild>
                    <Link href="/quote" className="flex items-center gap-2">
                      Start Similar Project
                      <ArrowRight className="h-5 w-5" />
                    </Link>
                  </Button>
                  <Button variant="outline" asChild>
                    <Link href="/contact">Contact Us</Link>
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CTA Section */}
      <section className="bg-primary py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl">
              Have a Project in Mind?
            </h2>
            <p className="mt-4 text-lg text-cream/80">
              From small events to mega installations, our experienced team is
              ready to handle projects of any scale. Let&apos;s discuss your
              requirements.
            </p>
            <div className="mt-10">
              <Button
                size="lg"
                asChild
                className="bg-gold text-dark-forest hover:bg-gold/90"
              >
                <Link href="/quote" className="flex items-center gap-2">
                  Discuss Your Project
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
