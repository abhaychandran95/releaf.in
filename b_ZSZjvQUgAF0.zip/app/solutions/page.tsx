"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Building2,
  Tent,
  Users,
  Factory,
  Droplets,
  Recycle,
  ArrowRight,
  CheckCircle,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";

const solutions = [
  {
    icon: Building2,
    title: "Construction Sites",
    description:
      "Heavy-duty portable toilets designed for the demanding conditions of construction environments. Built to withstand harsh weather and high-traffic usage.",
    features: [
      "Weather-resistant FRP construction",
      "Daily/weekly servicing options",
      "Bulk rental discounts available",
      "Quick 24-hour deployment",
      "OSHA compliant safety features",
    ],
    image:
      "https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/construction",
  },
  {
    icon: Tent,
    title: "Events & Gatherings",
    description:
      "Elegant and hygienic portable restroom solutions for weddings, corporate events, festivals, and large gatherings with VIP options available.",
    features: [
      "VIP & premium luxury units",
      "Climate-controlled options",
      "Professional attendant services",
      "Flexible rental periods",
      "Custom branding available",
    ],
    image:
      "https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/events",
  },
  {
    icon: Users,
    title: "Religious Sites",
    description:
      "Respectful and accessible sanitation infrastructure for temples, religious gatherings, and pilgrimage sites designed with cultural sensitivity.",
    features: [
      "High-capacity configurations",
      "Accessible units included",
      "24/7 maintenance support",
      "Eco-friendly waste management",
      "Multi-language signage",
    ],
    image:
      "https://images.unsplash.com/photo-1561361513-2d000a50f0dc?q=80&w=2076&auto=format&fit=crop",
    href: "/solutions/religious",
  },
  {
    icon: Factory,
    title: "STP Plants",
    description:
      "Complete sewage treatment plant design, installation, and maintenance services from small residential to large municipal projects.",
    features: [
      "Custom capacity design",
      "Turnkey project delivery",
      "Annual maintenance contracts",
      "Regulatory compliance support",
      "Water recycling integration",
    ],
    image:
      "https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/stp",
  },
  {
    icon: Droplets,
    title: "Wastewater Management",
    description:
      "Comprehensive wastewater collection, treatment, and recycling services for industrial, commercial, and residential applications.",
    features: [
      "Complete waste lifecycle management",
      "Treatment plant operations",
      "Recycled water supply",
      "Sludge management",
      "Environmental compliance",
    ],
    image:
      "https://images.unsplash.com/photo-1584466990297-9722a57cfcd5?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/wastewater",
  },
  {
    icon: Recycle,
    title: "Eco Solutions",
    description:
      "Sustainable and environmentally friendly sanitation solutions including bio-toilets, composting systems, and green infrastructure.",
    features: [
      "Bio-digester technology",
      "Solar-powered units",
      "Waterless urinals",
      "Composting systems",
      "Carbon footprint reduction",
    ],
    image:
      "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070&auto=format&fit=crop",
    href: "/solutions/eco",
  },
];

export default function SolutionsPage() {
  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-dark-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-4 py-2 text-sm font-medium text-gold">
              Our Solutions
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Comprehensive <span className="text-leaf">Sanitation</span>{" "}
              Solutions
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              From temporary event setups to permanent infrastructure, we deliver
              tailored solutions for every sanitation need.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Solutions Grid */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="space-y-20">
            {solutions.map((solution, index) => (
              <motion.div
                key={solution.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className={`grid items-center gap-12 lg:grid-cols-2 ${
                  index % 2 === 1 ? "lg:flex-row-reverse" : ""
                }`}
              >
                {/* Image */}
                <div
                  className={`relative overflow-hidden rounded-3xl ${
                    index % 2 === 1 ? "lg:order-2" : ""
                  }`}
                >
                  <div className="aspect-[4/3]">
                    <img
                      src={solution.image}
                      alt={solution.title}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="absolute left-6 top-6 flex items-center gap-3 rounded-xl bg-card/95 px-5 py-3 shadow-lg backdrop-blur-sm">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                      <solution.icon className="h-5 w-5" />
                    </div>
                    <span className="font-serif font-semibold text-card-foreground">
                      {solution.title}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className={index % 2 === 1 ? "lg:order-1" : ""}>
                  <h2 className="font-serif text-2xl font-bold text-foreground md:text-3xl lg:text-4xl">
                    {solution.title}
                  </h2>
                  <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                    {solution.description}
                  </p>

                  {/* Features */}
                  <ul className="mt-8 space-y-3">
                    {solution.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 shrink-0 text-primary" />
                        <span className="text-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <div className="mt-10 flex flex-wrap gap-4">
                    <Button asChild>
                      <Link
                        href={solution.href}
                        className="flex items-center gap-2"
                      >
                        Learn More
                        <ArrowRight className="h-5 w-5" />
                      </Link>
                    </Button>
                    <Button variant="outline" asChild>
                      <Link href="/quote">Get a Quote</Link>
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Solution Finder CTA */}
      <section className="bg-primary py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl">
              Not Sure Which Solution Fits Your Needs?
            </h2>
            <p className="mt-4 text-lg text-cream/80">
              Our sanitation experts will assess your requirements and recommend
              the perfect solution. Get a customized proposal within 24 hours.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-4">
              <Button
                size="lg"
                asChild
                className="bg-gold text-dark-forest hover:bg-gold/90"
              >
                <Link href="/quote" className="flex items-center gap-2">
                  Request Consultation
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="border-cream/30 text-cream hover:bg-cream/10"
              >
                <a href="tel:+919876543210">Call Now</a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
