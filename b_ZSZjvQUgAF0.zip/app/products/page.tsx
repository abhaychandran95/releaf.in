"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Building2,
  Award,
  Users,
  Factory,
  ArrowRight,
  CheckCircle,
  Star,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const categories = ["All Products", "Rental Units", "Purchase Options"];

const products = [
  {
    id: 1,
    name: "Standard Portable Toilet",
    category: "Rental Units",
    type: "rental",
    description:
      "Cost-effective portable toilet solution ideal for construction sites and basic outdoor events.",
    features: [
      "FRP construction",
      "Ventilation system",
      "Non-slip flooring",
      "Waste tank (100L)",
      "Hand wash station",
    ],
    pricing: "Starting from Rs. 3,500/month",
    popular: false,
    image:
      "https://images.unsplash.com/photo-1585771724684-38269d6639fd?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: 2,
    name: "Premium VIP Restroom",
    category: "Rental Units",
    type: "rental",
    description:
      "Luxury portable restroom with premium finishes for upscale events and VIP areas.",
    features: [
      "Air conditioning",
      "Full mirror & lighting",
      "Flush toilet system",
      "Running water sink",
      "Premium interiors",
      "Fragrance system",
    ],
    pricing: "Starting from Rs. 12,000/month",
    popular: true,
    image:
      "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: 3,
    name: "Accessible Unit",
    category: "Rental Units",
    type: "rental",
    description:
      "ADA-compliant wheelchair accessible portable toilet with spacious interior and grab bars.",
    features: [
      "Extra wide door",
      "Wheelchair ramp",
      "Interior grab bars",
      "Lowered fixtures",
      "Spacious interior",
      "Emergency call button",
    ],
    pricing: "Starting from Rs. 5,500/month",
    popular: false,
    image:
      "https://images.unsplash.com/photo-1504307651254-35680f356dfd?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: 4,
    name: "Trailer Restroom",
    category: "Rental Units",
    type: "rental",
    description:
      "Mobile restroom trailer with multiple stalls, perfect for large events and festivals.",
    features: [
      "Multiple stalls (2-8)",
      "Running water",
      "AC/heating option",
      "Generator ready",
      "External lighting",
      "Easy towability",
    ],
    pricing: "Starting from Rs. 25,000/event",
    popular: true,
    image:
      "https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: 5,
    name: "FRP Toilet Unit (Sale)",
    category: "Purchase Options",
    type: "purchase",
    description:
      "Durable FRP portable toilet available for outright purchase. Ideal for permanent site installations.",
    features: [
      "10+ year lifespan",
      "UV resistant",
      "Easy maintenance",
      "Customizable colors",
      "Installation support",
      "Warranty included",
    ],
    pricing: "Rs. 45,000 onwards",
    popular: false,
    image:
      "https://images.unsplash.com/photo-1611273426858-450d8e3c9fce?q=80&w=2070&auto=format&fit=crop",
  },
  {
    id: 6,
    name: "Bio-Digester Toilet",
    category: "Purchase Options",
    type: "purchase",
    description:
      "Eco-friendly bio-digester toilet that converts waste to water through bacterial action.",
    features: [
      "Zero discharge",
      "Low maintenance",
      "Odor free operation",
      "No sewage connection needed",
      "Eco-friendly",
      "DRDO technology",
    ],
    pricing: "Rs. 75,000 onwards",
    popular: true,
    image:
      "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070&auto=format&fit=crop",
  },
];

export default function ProductsPage() {
  const [activeCategory, setActiveCategory] = useState("All Products");

  const filteredProducts =
    activeCategory === "All Products"
      ? products
      : products.filter((p) => p.category === activeCategory);

  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-dark-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-4 py-2 text-sm font-medium text-gold">
              Our Products
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Quality <span className="text-leaf">Products</span> for Every Need
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              Explore our range of portable sanitation units available for rental
              and purchase.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Products Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          {/* Category Filter */}
          <div className="mb-12 flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={cn(
                  "rounded-full px-6 py-3 font-medium transition-all",
                  activeCategory === category
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                )}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative overflow-hidden rounded-2xl border border-border bg-card"
              >
                {/* Popular Badge */}
                {product.popular && (
                  <div className="absolute right-4 top-4 z-10 flex items-center gap-1 rounded-full bg-gold px-3 py-1 text-xs font-medium text-dark-forest">
                    <Star className="h-3 w-3" />
                    Popular
                  </div>
                )}

                {/* Image */}
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-forest/60 via-transparent to-transparent" />
                  <div className="absolute bottom-4 left-4">
                    <span
                      className={cn(
                        "rounded-full px-3 py-1 text-xs font-medium",
                        product.type === "rental"
                          ? "bg-primary text-primary-foreground"
                          : "bg-gold text-dark-forest"
                      )}
                    >
                      {product.type === "rental" ? "For Rent" : "For Sale"}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="font-serif text-xl font-bold text-card-foreground">
                    {product.name}
                  </h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {product.description}
                  </p>

                  {/* Features */}
                  <ul className="mt-4 space-y-2">
                    {product.features.slice(0, 4).map((feature) => (
                      <li
                        key={feature}
                        className="flex items-center gap-2 text-sm"
                      >
                        <CheckCircle className="h-4 w-4 text-primary" />
                        <span className="text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                    {product.features.length > 4 && (
                      <li className="text-sm text-primary">
                        +{product.features.length - 4} more features
                      </li>
                    )}
                  </ul>

                  {/* Pricing */}
                  <div className="mt-6 border-t border-border pt-4">
                    <p className="font-serif text-lg font-semibold text-primary">
                      {product.pricing}
                    </p>
                  </div>

                  {/* CTA */}
                  <div className="mt-4 flex gap-3">
                    <Button asChild className="flex-1">
                      <Link href="/quote">Get Quote</Link>
                    </Button>
                    <Button variant="outline" asChild>
                      <Link href={`/products/${product.id}`}>Details</Link>
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Custom Solutions CTA */}
      <section className="bg-secondary py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
              Need a Custom Solution?
            </h2>
            <p className="mt-4 text-lg text-muted-foreground">
              We can design and manufacture custom sanitation units tailored to
              your specific requirements. From branding to specialized features,
              we&apos;ve got you covered.
            </p>
            <div className="mt-10">
              <Button size="lg" asChild>
                <Link href="/contact" className="flex items-center gap-2">
                  Discuss Custom Requirements
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
