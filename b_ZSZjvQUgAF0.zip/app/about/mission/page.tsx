"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Target,
  Eye,
  Heart,
  Leaf,
  Users,
  Globe,
  ArrowRight,
  CheckCircle,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";

const missionPillars = [
  {
    icon: Users,
    title: "Dignity for All",
    description:
      "Ensuring access to clean, safe sanitation facilities for every individual, regardless of location or economic status.",
  },
  {
    icon: Leaf,
    title: "Environmental Stewardship",
    description:
      "Implementing sustainable practices that minimize environmental impact while maximizing resource efficiency.",
  },
  {
    icon: Globe,
    title: "Community Health",
    description:
      "Contributing to public health by preventing disease transmission through proper sanitation infrastructure.",
  },
  {
    icon: Heart,
    title: "Service Excellence",
    description:
      "Delivering unparalleled service quality that exceeds expectations and builds lasting partnerships.",
  },
];

const visionGoals = [
  "Be recognized as India&apos;s most trusted sanitation partner",
  "Achieve 100% sustainable operations by 2030",
  "Expand presence to every district in India",
  "Pioneer innovative eco-sanitation technologies",
  "Train 10,000+ sanitation professionals",
  "Contribute to India&apos;s Swachh Bharat mission",
];

export default function MissionPage() {
  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-dark-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-4 py-2 text-sm font-medium text-gold">
              Mission & Vision
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Building a{" "}
              <span className="text-leaf">Cleaner</span>,{" "}
              <span className="text-gold">Healthier</span> India
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              Our purpose drives every decision, every installation, and every
              interaction with our stakeholders.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="mb-6 flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
                  <Target className="h-8 w-8" />
                </div>
                <div>
                  <span className="text-sm font-medium text-muted-foreground">
                    Our Purpose
                  </span>
                  <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
                    Our Mission
                  </h2>
                </div>
              </div>
              <p className="text-xl leading-relaxed text-muted-foreground">
                To revolutionize sanitation standards across India by providing
                innovative, sustainable, and dignified sanitation solutions that
                protect public health and the environment while exceeding customer
                expectations.
              </p>
              <p className="mt-4 text-lg text-muted-foreground">
                We are committed to making quality sanitation accessible to all,
                whether at a remote construction site, a grand wedding celebration,
                or a sacred pilgrimage gathering.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid grid-cols-2 gap-4"
            >
              {missionPillars.map((pillar, index) => (
                <div
                  key={pillar.title}
                  className="rounded-2xl border border-border bg-card p-6"
                >
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                    <pillar.icon className="h-6 w-6" />
                  </div>
                  <h3 className="mb-2 font-serif font-semibold text-card-foreground">
                    {pillar.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {pillar.description}
                  </p>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="bg-primary py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-2 lg:order-1"
            >
              <div className="rounded-2xl bg-cream/10 p-8">
                <h3 className="mb-6 font-serif text-xl font-semibold text-cream">
                  Our Vision Goals for 2030
                </h3>
                <ul className="space-y-4">
                  {visionGoals.map((goal, index) => (
                    <motion.li
                      key={goal}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center gap-3"
                    >
                      <CheckCircle className="h-5 w-5 shrink-0 text-gold" />
                      <span className="text-cream/90">{goal}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="order-1 lg:order-2"
            >
              <div className="mb-6 flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gold text-dark-forest">
                  <Eye className="h-8 w-8" />
                </div>
                <div>
                  <span className="text-sm font-medium text-cream/70">
                    Our Aspiration
                  </span>
                  <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl">
                    Our Vision
                  </h2>
                </div>
              </div>
              <p className="text-xl leading-relaxed text-cream/90">
                To be the most trusted name in sanitation infrastructure across
                India, recognized for our commitment to quality, sustainability,
                and positive impact on community health.
              </p>
              <p className="mt-4 text-lg text-cream/80">
                We envision an India where every citizen has access to dignified
                sanitation, where sustainable practices are the norm, and where
                Releaf is synonymous with excellence in environmental
                infrastructure.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values in Action */}
      <section className="bg-secondary py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              Values in Action
            </span>
            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
              How We Live Our Mission
            </h2>
          </motion.div>

          <div className="grid gap-8 md:grid-cols-3">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="rounded-2xl bg-card p-8 shadow-sm"
            >
              <div className="mb-4 font-serif text-5xl font-bold text-primary">01</div>
              <h3 className="mb-3 font-serif text-xl font-semibold text-card-foreground">
                Customer Partnership
              </h3>
              <p className="text-muted-foreground">
                We don&apos;t just provide services; we build partnerships. Understanding
                unique needs and delivering customized solutions that exceed expectations.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="rounded-2xl bg-card p-8 shadow-sm"
            >
              <div className="mb-4 font-serif text-5xl font-bold text-primary">02</div>
              <h3 className="mb-3 font-serif text-xl font-semibold text-card-foreground">
                Sustainable Operations
              </h3>
              <p className="text-muted-foreground">
                Every unit deployed incorporates water-saving technologies and
                eco-friendly materials. Our waste disposal follows strict environmental
                guidelines.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="rounded-2xl bg-card p-8 shadow-sm"
            >
              <div className="mb-4 font-serif text-5xl font-bold text-primary">03</div>
              <h3 className="mb-3 font-serif text-xl font-semibold text-card-foreground">
                Community Impact
              </h3>
              <p className="text-muted-foreground">
                Beyond business, we actively support community health initiatives and
                provide subsidized services for social causes and public welfare events.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
              Join Us in Building a Cleaner India
            </h2>
            <p className="mt-4 text-lg text-muted-foreground">
              Whether you&apos;re looking for sanitation solutions or career
              opportunities, we&apos;d love to hear from you.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-4">
              <Button asChild size="lg">
                <Link href="/contact" className="flex items-center gap-2">
                  Contact Us
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link href="/careers">View Careers</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
