"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Shield,
  Award,
  FileCheck,
  BadgeCheck,
  CheckCircle,
  Download,
  ArrowRight,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";

const certifications = [
  {
    name: "ISO 9001:2015",
    category: "Quality Management",
    description:
      "International standard for quality management systems, ensuring consistent quality in all our products and services.",
    validUntil: "December 2026",
    icon: Shield,
    features: [
      "Quality management system",
      "Process optimization",
      "Customer satisfaction focus",
      "Continuous improvement",
    ],
  },
  {
    name: "ISO 14001:2015",
    category: "Environmental Management",
    description:
      "Certification for environmental management systems, demonstrating our commitment to sustainable practices.",
    validUntil: "December 2026",
    icon: Award,
    features: [
      "Environmental compliance",
      "Waste management protocols",
      "Pollution prevention",
      "Resource efficiency",
    ],
  },
  {
    name: "OHSAS 18001",
    category: "Occupational Health & Safety",
    description:
      "International standard for occupational health and safety management systems.",
    validUntil: "December 2025",
    icon: BadgeCheck,
    features: [
      "Workplace safety",
      "Risk assessment",
      "Employee health",
      "Incident prevention",
    ],
  },
  {
    name: "CPCB Approval",
    category: "Environmental Compliance",
    description:
      "Central Pollution Control Board approval for our waste treatment and disposal processes.",
    validUntil: "Ongoing",
    icon: FileCheck,
    features: [
      "Waste treatment standards",
      "Effluent quality compliance",
      "Environmental monitoring",
      "Regulatory adherence",
    ],
  },
];

const governmentEmpanelments = [
  "Ministry of Urban Development",
  "Ministry of Drinking Water & Sanitation",
  "Indian Railways",
  "Public Works Departments (Multiple States)",
  "Municipal Corporations (Major Cities)",
  "Defense Establishments",
];

const industryAssociations = [
  "Confederation of Indian Industry (CII)",
  "Federation of Indian Chambers of Commerce (FICCI)",
  "Indian Sanitation Coalition",
  "National Safety Council",
];

export default function CertificationsPage() {
  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-dark-forest via-dark-forest to-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-5 py-2 text-sm font-semibold text-gold">
              Quality Assurance
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Our{" "}
              <span className="text-leaf">Certifications</span>
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              Meeting international standards of quality, safety, and environmental
              responsibility in everything we do.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Certifications Grid */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
              International Standards
            </span>
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Quality Certifications
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-dark-forest/70">
              Our operations are certified to meet the highest international standards
            </p>
          </motion.div>

          <div className="grid gap-8 md:grid-cols-2">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group rounded-3xl border border-forest/10 bg-white p-8 shadow-lg transition-all hover:shadow-xl"
              >
                <div className="mb-6 flex items-start justify-between">
                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-forest to-dark-forest text-white shadow-lg">
                    <cert.icon className="h-8 w-8" />
                  </div>
                  <span className="rounded-full bg-gold/10 px-4 py-1 text-sm font-medium text-gold">
                    {cert.category}
                  </span>
                </div>

                <h3 className="font-serif text-2xl font-bold text-dark-forest">
                  {cert.name}
                </h3>
                <p className="mt-3 text-dark-forest/70">{cert.description}</p>

                <div className="mt-6">
                  <p className="mb-3 text-sm font-semibold uppercase tracking-wider text-dark-forest/50">
                    Coverage Areas:
                  </p>
                  <ul className="grid grid-cols-2 gap-2">
                    {cert.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-forest" />
                        <span className="text-dark-forest/70">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-6 flex items-center justify-between border-t border-forest/10 pt-6">
                  <span className="text-sm text-dark-forest/60">
                    Valid until: <span className="font-semibold text-forest">{cert.validUntil}</span>
                  </span>
                  <Button variant="ghost" size="sm" className="text-forest">
                    <Download className="mr-2 h-4 w-4" />
                    Certificate
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Government Empanelments */}
      <section className="bg-gradient-to-b from-secondary to-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
                Government Recognition
              </span>
              <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
                Official Empanelments
              </h2>
              <p className="mt-4 text-lg text-dark-forest/70">
                We are proud to be empaneled with major government bodies across India,
                trusted to deliver critical sanitation infrastructure for public projects.
              </p>
              <div className="mt-8 space-y-3">
                {governmentEmpanelments.map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-3 rounded-xl bg-white p-4 shadow-sm"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-forest/10">
                      <BadgeCheck className="h-5 w-5 text-forest" />
                    </div>
                    <span className="font-medium text-dark-forest">{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <div className="rounded-3xl bg-forest p-8 text-cream shadow-xl">
                <Shield className="mb-6 h-12 w-12 text-gold" />
                <h3 className="font-serif text-2xl font-bold">Industry Associations</h3>
                <p className="mt-4 text-cream/80">
                  Active membership in leading industry bodies, contributing to standards
                  development and best practices.
                </p>
                <div className="mt-6 space-y-3">
                  {industryAssociations.map((item) => (
                    <div key={item} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-gold" />
                      <span className="text-cream/90">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-white py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Need Compliance Documentation?
            </h2>
            <p className="mt-4 text-lg text-dark-forest/70">
              We can provide detailed compliance documentation and certifications
              for your project requirements.
            </p>
            <div className="mt-10">
              <Button size="lg" asChild className="rounded-full">
                <Link href="/contact" className="flex items-center gap-2">
                  Request Documentation
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
