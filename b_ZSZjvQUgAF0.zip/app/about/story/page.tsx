"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Clock,
  Award,
  Users,
  Target,
  Leaf,
  Building2,
  Heart,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";

const timeline = [
  {
    year: "1991",
    title: "The Beginning",
    description:
      "Founded as India's first organized portable sanitation company in Mumbai, introducing modern sanitation concepts to the Indian market with just 10 portable units.",
    icon: Leaf,
  },
  {
    year: "1996",
    title: "First Major Contract",
    description:
      "Secured first major government contract for a state-level sports event, proving our capability to handle large-scale sanitation requirements.",
    icon: Award,
  },
  {
    year: "2001",
    title: "Pan-India Expansion",
    description:
      "Expanded operations to cover all major metros including Delhi, Chennai, Kolkata, and Bangalore. Established regional offices and logistics hubs.",
    icon: Building2,
  },
  {
    year: "2005",
    title: "ISO Certification",
    description:
      "Achieved ISO 9001:2000 certification, becoming the first portable sanitation company in India to meet international quality standards.",
    icon: Award,
  },
  {
    year: "2010",
    title: "Kumbh Mela Partnership",
    description:
      "Became official sanitation partner for Kumbh Mela, managing over 5000 units for millions of pilgrims - our largest deployment ever.",
    icon: Users,
  },
  {
    year: "2015",
    title: "STP Division Launch",
    description:
      "Launched dedicated Sewage Treatment Plant division, entering the permanent infrastructure segment with turnkey solutions.",
    icon: Building2,
  },
  {
    year: "2020",
    title: "COVID-19 Response",
    description:
      "Deployed sanitation facilities at hospitals, quarantine centers, and testing sites across the country during the pandemic.",
    icon: Heart,
  },
  {
    year: "2024",
    title: "Continuing Excellence",
    description:
      "33+ years of excellence with 5000+ active installations, 1M+ daily users, and presence in 28 states across India.",
    icon: Target,
  },
];

const stats = [
  { value: "1991", label: "Year Founded" },
  { value: "33+", label: "Years of Service" },
  { value: "500+", label: "Employees" },
  { value: "28", label: "States Covered" },
];

export default function StoryPage() {
  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-dark-forest via-dark-forest to-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-5 py-2 text-sm font-semibold text-gold">
              Our Story
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              A Legacy of{" "}
              <span className="text-leaf">Clean Beginnings</span>
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              From a small startup with 10 units to India&apos;s largest portable
              sanitation company - discover our journey of innovation and impact.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative -mt-12 z-10 px-6">
        <div className="mx-auto max-w-4xl">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="rounded-2xl bg-white p-6 text-center shadow-xl"
              >
                <p className="font-serif text-3xl font-bold text-forest">{stat.value}</p>
                <p className="mt-1 text-sm text-dark-forest/60">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Origin Story */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
                Where It All Started
              </span>
              <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
                A Vision Born from Necessity
              </h2>
              <div className="mt-6 space-y-4 text-lg leading-relaxed text-dark-forest/70">
                <p>
                  In 1991, our founder Mr. Rajesh Sharma noticed a critical gap in
                  India&apos;s sanitation infrastructure. Construction sites, events, and
                  public gatherings lacked proper sanitation facilities, leading to
                  unhygienic conditions and health hazards.
                </p>
                <p>
                  Starting with just 10 imported portable units and a small team of 5,
                  Releaf began its mission to bring dignity through cleanliness. The early
                  years were challenging - educating the market about portable sanitation
                  was an uphill battle.
                </p>
                <p>
                  Today, we serve over 1 million users daily through 5000+ installations
                  across India. Our journey from those 10 units to becoming the nation&apos;s
                  most trusted sanitation partner is a testament to our commitment to
                  excellence and innovation.
                </p>
              </div>
              <div className="mt-8">
                <Button asChild className="rounded-full">
                  <Link href="/about/mission" className="flex items-center gap-2">
                    Our Mission & Vision
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="rounded-2xl bg-forest/10 p-6">
                    <Leaf className="mb-3 h-8 w-8 text-forest" />
                    <h3 className="font-serif text-xl font-semibold text-dark-forest">
                      Eco-Friendly
                    </h3>
                    <p className="mt-2 text-sm text-dark-forest/60">
                      Pioneering sustainable sanitation practices from day one
                    </p>
                  </div>
                  <div className="rounded-2xl bg-gold/10 p-6">
                    <Award className="mb-3 h-8 w-8 text-gold" />
                    <h3 className="font-serif text-xl font-semibold text-dark-forest">
                      Quality First
                    </h3>
                    <p className="mt-2 text-sm text-dark-forest/60">
                      ISO certified operations ensuring highest standards
                    </p>
                  </div>
                </div>
                <div className="mt-8 space-y-4">
                  <div className="rounded-2xl bg-leaf/10 p-6">
                    <Users className="mb-3 h-8 w-8 text-leaf" />
                    <h3 className="font-serif text-xl font-semibold text-dark-forest">
                      Customer Focus
                    </h3>
                    <p className="mt-2 text-sm text-dark-forest/60">
                      Building lasting relationships through trust
                    </p>
                  </div>
                  <div className="rounded-2xl bg-dark-forest/10 p-6">
                    <Target className="mb-3 h-8 w-8 text-dark-forest" />
                    <h3 className="font-serif text-xl font-semibold text-dark-forest">
                      Innovation
                    </h3>
                    <p className="mt-2 text-sm text-dark-forest/60">
                      Constantly evolving to meet changing needs
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="bg-gradient-to-b from-secondary to-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
              Our Journey
            </span>
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Milestones That Define Us
            </h2>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-8 top-0 hidden h-full w-0.5 bg-forest/20 md:left-1/2 md:-translate-x-1/2 lg:block" />

            <div className="space-y-8">
              {timeline.map((item, index) => (
                <motion.div
                  key={item.year}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative flex flex-col gap-6 lg:flex-row lg:items-center ${
                    index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
                  }`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? "lg:text-right lg:pr-12" : "lg:text-left lg:pl-12"}`}>
                    <div className={`rounded-2xl bg-white p-6 shadow-lg ${index % 2 === 0 ? "lg:ml-auto" : "lg:mr-auto"} max-w-xl`}>
                      <div className="flex items-center gap-3 lg:justify-start">
                        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold/20 text-gold lg:hidden">
                          <item.icon className="h-5 w-5" />
                        </div>
                        <p className="font-serif text-2xl font-bold text-forest">{item.year}</p>
                      </div>
                      <h3 className="mt-3 font-serif text-xl font-semibold text-dark-forest">
                        {item.title}
                      </h3>
                      <p className="mt-2 text-dark-forest/70">{item.description}</p>
                    </div>
                  </div>

                  {/* Center Icon */}
                  <div className="absolute left-8 top-6 z-10 hidden h-12 w-12 -translate-x-1/2 items-center justify-center rounded-full bg-forest text-white shadow-lg md:left-1/2 lg:flex">
                    <item.icon className="h-6 w-6" />
                  </div>

                  <div className="hidden flex-1 lg:block" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-forest py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl">
              Be Part of Our Story
            </h2>
            <p className="mt-4 text-lg text-cream/80">
              Join us in our mission to make India cleaner and healthier.
              Whether as a client, partner, or team member.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-4">
              <Button size="lg" asChild className="rounded-full bg-gold text-dark-forest hover:bg-gold/90">
                <Link href="/contact">Partner With Us</Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="rounded-full border-cream/30 text-cream hover:bg-cream/10">
                <Link href="/careers">Join Our Team</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
