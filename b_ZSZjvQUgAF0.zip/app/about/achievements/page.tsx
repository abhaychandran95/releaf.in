"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Trophy,
  Award,
  Star,
  Medal,
  ArrowRight,
  CheckCircle,
  Users,
  Building2,
  Leaf,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";

const awards = [
  {
    year: "2023",
    title: "Excellence in Environmental Innovation",
    organization: "CII Green Building Council",
    description: "Recognized for pioneering eco-friendly sanitation solutions and sustainable waste management practices.",
    icon: Leaf,
  },
  {
    year: "2022",
    title: "Best Sanitation Service Provider",
    organization: "Ministry of Urban Development",
    description: "National recognition for outstanding contribution to Swachh Bharat Mission.",
    icon: Trophy,
  },
  {
    year: "2021",
    title: "COVID Response Excellence Award",
    organization: "PHD Chamber of Commerce",
    description: "For rapid deployment of sanitation facilities at hospitals and quarantine centers during the pandemic.",
    icon: Medal,
  },
  {
    year: "2020",
    title: "Industry Leadership Award",
    organization: "Indian Sanitation Coalition",
    description: "Recognized as industry leader in portable sanitation and wastewater management.",
    icon: Award,
  },
  {
    year: "2019",
    title: "Best Corporate Practices",
    organization: "National Safety Council",
    description: "For maintaining exemplary health and safety standards across all operations.",
    icon: Star,
  },
  {
    year: "2018",
    title: "Sustainable Business Award",
    organization: "FICCI",
    description: "For commitment to sustainable business practices and environmental stewardship.",
    icon: Leaf,
  },
];

const milestones = [
  { year: "1991", achievement: "First organized portable sanitation company in India" },
  { year: "1998", achievement: "Crossed 100 active installations milestone" },
  { year: "2005", achievement: "First ISO 9001 certified portable sanitation company" },
  { year: "2010", achievement: "Official Kumbh Mela sanitation partner" },
  { year: "2015", achievement: "Reached 1000+ active installations pan-India" },
  { year: "2018", achievement: "1 Million daily users milestone" },
  { year: "2020", achievement: "Deployed 500+ units for COVID response" },
  { year: "2024", achievement: "5000+ active installations across 28 states" },
];

const impactNumbers = [
  { value: "1M+", label: "Daily Users Served" },
  { value: "5000+", label: "Active Installations" },
  { value: "500+", label: "Organizations Served" },
  { value: "28", label: "States Covered" },
];

export default function AchievementsPage() {
  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-dark-forest via-dark-forest to-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-5 py-2 text-sm font-semibold text-gold">
              Recognition
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Our{" "}
              <span className="text-leaf">Achievements</span>
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              33+ years of excellence recognized through numerous awards and
              milestones that define our journey.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Impact Numbers */}
      <section className="relative -mt-12 z-10 px-6">
        <div className="mx-auto max-w-5xl">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {impactNumbers.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="rounded-2xl bg-white p-6 text-center shadow-xl"
              >
                <p className="font-serif text-3xl font-bold text-forest md:text-4xl">{stat.value}</p>
                <p className="mt-1 text-sm text-dark-forest/60">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Awards Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
              Awards & Recognition
            </span>
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Industry Recognition
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-dark-forest/70">
              Our commitment to excellence has been recognized by leading organizations
            </p>
          </motion.div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {awards.map((award, index) => (
              <motion.div
                key={award.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group rounded-3xl border border-forest/10 bg-white p-8 shadow-lg transition-all hover:shadow-xl"
              >
                <div className="mb-6 flex items-start justify-between">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-gold to-yellow-600 text-white shadow-lg">
                    <award.icon className="h-7 w-7" />
                  </div>
                  <span className="rounded-full bg-forest/10 px-4 py-1 text-sm font-bold text-forest">
                    {award.year}
                  </span>
                </div>
                <h3 className="font-serif text-xl font-bold text-dark-forest">
                  {award.title}
                </h3>
                <p className="mt-2 text-sm font-medium text-gold">{award.organization}</p>
                <p className="mt-3 text-dark-forest/70">{award.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Milestones Timeline */}
      <section className="bg-gradient-to-b from-secondary to-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
              Key Milestones
            </span>
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Historic Achievements
            </h2>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-4 top-0 h-full w-0.5 bg-forest/20 md:left-1/2 md:-translate-x-1/2" />

            <div className="space-y-6">
              {milestones.map((milestone, index) => (
                <motion.div
                  key={milestone.year}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`relative flex items-center ${index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12 md:text-left"} pl-12 md:pl-0`}>
                    <div className={`inline-block rounded-2xl bg-white p-6 shadow-lg ${index % 2 === 0 ? "md:ml-auto" : "md:mr-auto"}`}>
                      <span className="font-serif text-2xl font-bold text-forest">{milestone.year}</span>
                      <p className="mt-2 text-dark-forest/80">{milestone.achievement}</p>
                    </div>
                  </div>

                  {/* Center Dot */}
                  <div className="absolute left-4 flex h-8 w-8 -translate-x-1/2 items-center justify-center rounded-full bg-forest text-white shadow-lg md:left-1/2">
                    <CheckCircle className="h-4 w-4" />
                  </div>

                  <div className="hidden flex-1 md:block" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-forest py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Trophy className="mx-auto mb-6 h-16 w-16 text-gold" />
            <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl">
              Be Part of Our Success Story
            </h2>
            <p className="mt-4 text-lg text-cream/80">
              Partner with India&apos;s most awarded sanitation company for your
              next project.
            </p>
            <div className="mt-10 flex flex-wrap justify-center gap-4">
              <Button size="lg" asChild className="rounded-full bg-gold text-dark-forest hover:bg-gold/90">
                <Link href="/contact">Start a Project</Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="rounded-full border-cream/30 text-cream hover:bg-cream/10">
                <Link href="/about/story">Our Story</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
