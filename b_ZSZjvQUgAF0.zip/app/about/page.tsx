"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Award,
  Shield,
  Leaf,
  Clock,
  ArrowRight,
  Target,
  Heart,
  Users,
  CheckCircle,
  Building2,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";

const timeline = [
  {
    year: "1991",
    title: "The Beginning",
    description:
      "Founded as India&apos;s first organized portable sanitation company, introducing modern sanitation concepts to the Indian market.",
  },
  {
    year: "1998",
    title: "Pan-India Expansion",
    description:
      "Expanded operations to cover all major metros and established a robust logistics network across the country.",
  },
  {
    year: "2005",
    title: "ISO Certification",
    description:
      "Achieved ISO 9001:2000 certification, setting new quality standards in the Indian portable sanitation industry.",
  },
  {
    year: "2012",
    title: "STP Division Launch",
    description:
      "Launched dedicated Sewage Treatment Plant division, entering the permanent infrastructure segment.",
  },
  {
    year: "2018",
    title: "1 Million Mark",
    description:
      "Served over 1 million users daily across all installations, a major milestone in our journey.",
  },
  {
    year: "2024",
    title: "Continuing Excellence",
    description:
      "33+ years of excellence with 5000+ active installations and presence in 28 states across India.",
  },
];

const values = [
  {
    icon: Heart,
    title: "Customer First",
    description:
      "Every decision we make is guided by our commitment to exceeding customer expectations and delivering value.",
  },
  {
    icon: Leaf,
    title: "Sustainability",
    description:
      "Environmental responsibility is at the core of our operations, from water-saving technologies to eco-friendly waste disposal.",
  },
  {
    icon: Shield,
    title: "Quality & Safety",
    description:
      "We maintain the highest standards of quality and safety in all our products and services.",
  },
  {
    icon: Users,
    title: "Team Excellence",
    description:
      "Our strength lies in our dedicated team of professionals who bring passion and expertise to every project.",
  },
];

const achievements = [
  "First portable toilet company in India",
  "ISO 9001:2015 certified operations",
  "Largest Kumbh Mela sanitation partner",
  "Government of India empaneled vendor",
  "500+ corporate clients served",
  "Zero environmental violations record",
];

export default function AboutPage() {
  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-dark-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-4 py-2 text-sm font-medium text-gold">
              About Us
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              India&apos;s Pioneer in{" "}
              <span className="text-leaf">Eco-Sanitation</span>
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              Since 1991, we&apos;ve been transforming sanitation standards across
              India, one installation at a time.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
                Our Story
              </span>
              <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
                A Legacy of Clean Beginnings
              </h2>
              <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
                In 1991, when portable sanitation was virtually unknown in India,
                our founder had a vision: to bring dignity and cleanliness to
                every corner of the nation through modern sanitation solutions.
              </p>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                What started as a small operation with just a handful of units
                has grown into India&apos;s most trusted sanitation infrastructure
                company. Today, we serve millions of users daily across 28 states,
                from construction sites to mega religious gatherings.
              </p>
              <p className="mt-4 text-lg leading-relaxed text-muted-foreground">
                Our journey has been marked by innovation, commitment to quality,
                and an unwavering focus on customer satisfaction. We&apos;ve evolved
                from portable toilets to complete wastewater management solutions,
                always staying ahead of industry trends.
              </p>

              <div className="mt-8 flex flex-wrap gap-4">
                <Button asChild>
                  <Link href="/about/mission" className="flex items-center gap-2">
                    Our Mission
                    <ArrowRight className="h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/contact">Contact Us</Link>
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="grid grid-cols-2 gap-4">
                <img
                  src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=1974&auto=format&fit=crop"
                  alt="Team collaboration"
                  className="h-48 w-full rounded-2xl object-cover lg:h-64"
                />
                <img
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=2070&auto=format&fit=crop"
                  alt="Professional meeting"
                  className="mt-8 h-48 w-full rounded-2xl object-cover lg:h-64"
                />
              </div>
              {/* Stats Badge */}
              <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 rounded-2xl bg-primary px-8 py-6 text-center text-primary-foreground shadow-xl">
                <p className="font-serif text-4xl font-bold">33+</p>
                <p className="text-sm">Years of Excellence</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="bg-secondary py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              Our Journey
            </span>
            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
              Milestones That Define Us
            </h2>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 top-0 hidden h-full w-0.5 -translate-x-1/2 bg-border lg:block" />

            <div className="space-y-12">
              {timeline.map((item, index) => (
                <motion.div
                  key={item.year}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex flex-col items-center gap-8 lg:flex-row ${
                    index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
                  }`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? "lg:text-right" : "lg:text-left"}`}>
                    <div
                      className={`rounded-2xl bg-card p-6 shadow-sm ${
                        index % 2 === 0 ? "lg:ml-auto lg:mr-8" : "lg:ml-8 lg:mr-auto"
                      } max-w-md`}
                    >
                      <p className="font-serif text-3xl font-bold text-primary">
                        {item.year}
                      </p>
                      <h3 className="mt-2 font-serif text-xl font-semibold text-card-foreground">
                        {item.title}
                      </h3>
                      <p className="mt-2 text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                  <div className="relative z-10 flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div className="hidden flex-1 lg:block" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              Our Values
            </span>
            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
              What Drives Us Forward
            </h2>
          </motion.div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="rounded-2xl border border-border bg-card p-8 text-center"
              >
                <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <value.icon className="h-8 w-8" />
                </div>
                <h3 className="mb-3 font-serif text-xl font-semibold text-card-foreground">
                  {value.title}
                </h3>
                <p className="text-muted-foreground">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="bg-primary py-20">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="mb-4 inline-block rounded-full bg-cream/20 px-4 py-2 text-sm font-medium text-cream">
                Achievements
              </span>
              <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl">
                Recognition of Excellence
              </h2>
              <p className="mt-4 text-lg text-cream/80">
                Our commitment to quality and innovation has been recognized
                through numerous achievements and certifications over the years.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid gap-4 sm:grid-cols-2"
            >
              {achievements.map((achievement, index) => (
                <div
                  key={achievement}
                  className="flex items-center gap-3 rounded-xl bg-cream/10 p-4"
                >
                  <CheckCircle className="h-5 w-5 shrink-0 text-gold" />
                  <span className="text-cream">{achievement}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Leadership Team Preview */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              Leadership
            </span>
            <h2 className="font-serif text-3xl font-bold text-foreground md:text-4xl">
              Meet Our Team
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
              Our experienced leadership team brings decades of industry expertise
              to guide Releaf&apos;s continued growth and innovation.
            </p>
            <div className="mt-10">
              <Button asChild size="lg">
                <Link href="/about/team" className="flex items-center gap-2">
                  View Full Team
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
