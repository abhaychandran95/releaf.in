"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Linkedin,
  Mail,
  ArrowRight,
  Users,
  Award,
  Target,
} from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";

const leadership = [
  {
    name: "Rajesh Sharma",
    role: "Founder & Managing Director",
    bio: "Founded Releaf in 1991 with a vision to transform sanitation standards in India. Over 35 years of experience in environmental infrastructure.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
  },
  {
    name: "Priya Mehta",
    role: "Chief Executive Officer",
    bio: "Leading Releaf's strategic growth and operations for the past 15 years. Former consultant at McKinsey with expertise in infrastructure.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop",
  },
  {
    name: "Amit Patel",
    role: "Chief Operations Officer",
    bio: "Oversees pan-India operations with 20+ years in logistics and supply chain management. Ensures seamless service delivery across all regions.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
  },
  {
    name: "Dr. Sunita Reddy",
    role: "Chief Technology Officer",
    bio: "Leads R&D and innovation initiatives. PhD in Environmental Engineering from IIT Delhi. Pioneer in bio-digester technology adaptation.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop",
  },
];

const departments = [
  {
    name: "Vikram Singh",
    role: "VP - Sales & Marketing",
    bio: "Driving business growth across B2B and B2G segments with innovative go-to-market strategies.",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop",
  },
  {
    name: "Ananya Krishnan",
    role: "VP - Human Resources",
    bio: "Building a world-class team and fostering a culture of excellence and innovation.",
    image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=400&h=400&fit=crop",
  },
  {
    name: "Rohit Gupta",
    role: "VP - Finance",
    bio: "Managing financial operations and strategic investments for sustainable growth.",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&h=400&fit=crop",
  },
  {
    name: "Meera Joshi",
    role: "VP - Quality & Compliance",
    bio: "Ensuring adherence to international quality standards and regulatory compliance.",
    image: "https://images.unsplash.com/photo-1598550874175-4d0ef436c909?w=400&h=400&fit=crop",
  },
];

const stats = [
  { value: "500+", label: "Team Members" },
  { value: "50+", label: "Engineers" },
  { value: "28", label: "Regional Teams" },
  { value: "15+", label: "Avg Years Experience" },
];

export default function TeamPage() {
  return (
    <main>
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-dark-forest via-dark-forest to-forest py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_40%,rgba(92,184,92,0.3),transparent_50%)]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="mx-auto max-w-3xl text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-gold/20 px-5 py-2 text-sm font-semibold text-gold">
              Our Team
            </span>
            <h1 className="font-serif text-4xl font-bold text-cream md:text-5xl lg:text-6xl">
              Meet the People Behind{" "}
              <span className="text-leaf">Releaf</span>
            </h1>
            <p className="mt-6 text-lg text-cream/80 md:text-xl">
              A passionate team of professionals dedicated to transforming
              sanitation standards across India.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="relative -mt-12 z-10 px-6">
        <div className="mx-auto max-w-4xl">
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="rounded-2xl bg-white p-6 text-center shadow-xl"
              >
                <p className="font-serif text-3xl font-bold text-forest">{stat.value}</p>
                <p className="mt-1 text-sm text-dark-forest/60">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Section */}
      <section className="bg-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
              Leadership
            </span>
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Executive Team
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-dark-forest/70">
              Experienced leaders driving Releaf&apos;s vision of a cleaner India
            </p>
          </motion.div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {leadership.map((person, index) => (
              <motion.div
                key={person.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group"
              >
                <div className="relative overflow-hidden rounded-3xl bg-white shadow-lg transition-all hover:shadow-xl">
                  <div className="relative aspect-square overflow-hidden">
                    <img
                      src={person.image}
                      alt={person.name}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-dark-forest/80 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                    <div className="absolute bottom-4 left-4 right-4 flex gap-2 opacity-0 transition-opacity group-hover:opacity-100">
                      <button className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-dark-forest transition-colors hover:bg-white">
                        <Linkedin className="h-5 w-5" />
                      </button>
                      <button className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-dark-forest transition-colors hover:bg-white">
                        <Mail className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="font-serif text-xl font-bold text-dark-forest">
                      {person.name}
                    </h3>
                    <p className="mt-1 text-sm font-medium text-forest">{person.role}</p>
                    <p className="mt-3 text-sm text-dark-forest/70">{person.bio}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Department Heads */}
      <section className="bg-gradient-to-b from-secondary to-background py-20">
        <div className="mx-auto max-w-7xl px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-16 text-center"
          >
            <span className="mb-4 inline-block rounded-full bg-forest/10 px-4 py-2 text-sm font-semibold text-forest">
              Department Heads
            </span>
            <h2 className="font-serif text-3xl font-bold text-dark-forest md:text-4xl">
              Functional Leaders
            </h2>
          </motion.div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {departments.map((person, index) => (
              <motion.div
                key={person.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="rounded-2xl bg-white p-6 shadow-lg"
              >
                <img
                  src={person.image}
                  alt={person.name}
                  className="mx-auto h-24 w-24 rounded-full object-cover ring-4 ring-forest/10"
                />
                <div className="mt-4 text-center">
                  <h3 className="font-serif text-lg font-bold text-dark-forest">
                    {person.name}
                  </h3>
                  <p className="text-sm font-medium text-forest">{person.role}</p>
                  <p className="mt-2 text-sm text-dark-forest/70">{person.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Join Us CTA */}
      <section className="bg-forest py-20">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Users className="mx-auto mb-6 h-16 w-16 text-gold" />
            <h2 className="font-serif text-3xl font-bold text-cream md:text-4xl">
              Join Our Growing Team
            </h2>
            <p className="mt-4 text-lg text-cream/80">
              We&apos;re always looking for passionate individuals who share our
              vision of a cleaner India. Explore career opportunities with us.
            </p>
            <div className="mt-10">
              <Button size="lg" asChild className="rounded-full bg-gold text-dark-forest hover:bg-gold/90">
                <Link href="/careers" className="flex items-center gap-2">
                  View Open Positions
                  <ArrowRight className="h-5 w-5" />
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </main>
  );
}
