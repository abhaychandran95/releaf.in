import type { Metadata, Viewport } from "next";
import { DM_Sans, Fraunces } from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import "./globals.css";

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-dm-sans",
  display: "swap",
});

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-fraunces",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Releaf | India's Pioneer in Eco-Sanitation Since 1991",
  description:
    "Releaf provides premium portable sanitation and wastewater management solutions. 33+ years of excellence serving governments, corporations, and events across India.",
  keywords: [
    "eco sanitation",
    "portable toilets",
    "wastewater management",
    "environmental infrastructure",
    "portable restrooms India",
    "construction sanitation",
    "event toilets",
    "STP plants",
  ],
  authors: [{ name: "Releaf" }],
  openGraph: {
    title: "Releaf | India's Pioneer in Eco-Sanitation Since 1991",
    description:
      "Premium portable sanitation and wastewater management solutions with 33+ years of excellence.",
    type: "website",
    locale: "en_IN",
    siteName: "Releaf",
  },
  twitter: {
    card: "summary_large_image",
    title: "Releaf | India's Pioneer in Eco-Sanitation Since 1991",
    description:
      "Premium portable sanitation and wastewater management solutions with 33+ years of excellence.",
  },
  icons: {
    icon: [
      {
        url: "/icon-light-32x32.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/icon-dark-32x32.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/apple-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#2D6A2D",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${dmSans.variable} ${fraunces.variable} bg-background`}
    >
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === "production" && <Analytics />}
      </body>
    </html>
  );
}
